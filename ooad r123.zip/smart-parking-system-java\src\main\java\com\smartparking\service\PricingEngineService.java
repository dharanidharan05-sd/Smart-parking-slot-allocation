package com.smartparking.service;

import com.smartparking.dto.ExitCalculationDTO;
import com.smartparking.entity.ParkingSession;
import com.smartparking.enums.BillingPlan;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;

@Service
public class PricingEngineService {

    /**
     * Calculates parking fee using the IMMUTABLE price snapshot stored on the session.
     */
    public ExitCalculationDTO calculateFee(ParkingSession session, LocalDateTime exitTime, Double customDiscountPercent) {
        if (exitTime == null) {
            exitTime = LocalDateTime.now();
        }

        Duration duration = Duration.between(session.getEntryTime(), exitTime);
        long durationMinutes = Math.max(0, duration.toMinutes());
        double durationHours = (double) durationMinutes / 60.0;

        BigDecimal hourlyRate = session.getSnapshotHourlyRate() != null ? session.getSnapshotHourlyRate() : BigDecimal.valueOf(30.0);
        BigDecimal dailyRate = session.getSnapshotDailyRate() != null ? session.getSnapshotDailyRate() : BigDecimal.valueOf(180.0);
        int graceMinutes = session.getSnapshotGraceMinutes() != null ? session.getSnapshotGraceMinutes() : 15;
        BigDecimal overtimeRate = session.getSnapshotOvertimeRate() != null ? session.getSnapshotOvertimeRate() : hourlyRate.multiply(BigDecimal.valueOf(1.5));
        double taxPercent = session.getSnapshotTaxPercent() != null ? session.getSnapshotTaxPercent() : 18.0;

        BigDecimal baseAmount = BigDecimal.ZERO;
        BigDecimal penaltyAmount = BigDecimal.ZERO;

        if (Boolean.TRUE.equals(session.getHasActivePass())) {
            // Subscription pass covers base fee
            baseAmount = BigDecimal.ZERO;
        } else if (session.getBillingPlan() == BillingPlan.HOURLY) {
            if (durationMinutes <= graceMinutes) {
                baseAmount = BigDecimal.ZERO; // Free 15-minute grace period
            } else {
                long billedHours = (long) Math.ceil((double) durationMinutes / 60.0);
                baseAmount = hourlyRate.multiply(BigDecimal.valueOf(billedHours));
            }
        } else if (session.getBillingPlan() == BillingPlan.DAILY) {
            long billedDays = Math.max(1, (long) Math.ceil(durationHours / 24.0));
            baseAmount = dailyRate.multiply(BigDecimal.valueOf(billedDays));

            // Overtime penalty if stayed past paid 24-hr blocks with grace allowance
            double allowedHours = billedDays * 24.0;
            if (durationHours > (allowedHours + ((double) graceMinutes / 60.0))) {
                long extraHours = (long) Math.ceil(durationHours - allowedHours);
                penaltyAmount = overtimeRate.multiply(BigDecimal.valueOf(extraHours));
            }
        }

        // Apply discount
        double discRate = customDiscountPercent != null ? customDiscountPercent : 0.0;
        BigDecimal discountAmount = baseAmount.multiply(BigDecimal.valueOf(discRate / 100.0)).setScale(2, RoundingMode.HALF_UP);

        // Tax calculation (GST 18%)
        BigDecimal taxableAmount = baseAmount.subtract(discountAmount).add(penaltyAmount).max(BigDecimal.ZERO);
        BigDecimal taxAmount = taxableAmount.multiply(BigDecimal.valueOf(taxPercent / 100.0)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalAmount = taxableAmount.add(taxAmount).setScale(2, RoundingMode.HALF_UP);

        return new ExitCalculationDTO(
            durationMinutes,
            formatDuration(durationMinutes),
            baseAmount.setScale(2, RoundingMode.HALF_UP),
            discountAmount,
            taxAmount,
            penaltyAmount.setScale(2, RoundingMode.HALF_UP),
            totalAmount
        );
    }

    public String formatDuration(long minutes) {
        long days = minutes / (24 * 60);
        long remMins = minutes % (24 * 60);
        long hours = remMins / 60;
        long mins = remMins % 60;

        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (hours > 0) sb.append(hours).append("h ");
        sb.append(mins).append("m");
        return sb.toString().trim();
    }
}
