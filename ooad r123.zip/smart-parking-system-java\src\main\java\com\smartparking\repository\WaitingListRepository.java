package com.smartparking.repository;

import com.smartparking.entity.WaitingList;
import com.smartparking.enums.VehicleCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface WaitingListRepository extends JpaRepository<WaitingList, Long> {
    List<WaitingList> findByStatusOrderByRequestedTimeAsc(String status);
    Optional<WaitingList> findFirstByCategoryAndStatusOrderByRequestedTimeAsc(VehicleCategory category, String status);
    Optional<WaitingList> findByVehicleNumberAndCategoryAndStatus(String vehicleNumber, VehicleCategory category, String status);
    long countByCategoryAndStatusAndRequestedTimeLessThanEqual(VehicleCategory category, String status, LocalDateTime time);
}
