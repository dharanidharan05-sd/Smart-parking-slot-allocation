package com.smartparking.dto;

import java.math.BigDecimal;

public class ExitCalculationDTO {
    private Long durationMinutes;
    private String durationFormatted;
    private BigDecimal baseAmount;
    private BigDecimal discountAmount;
    private BigDecimal taxAmount;
    private BigDecimal penaltyAmount;
    private BigDecimal totalAmount;

    public ExitCalculationDTO() {}

    public ExitCalculationDTO(Long durationMinutes, String durationFormatted, BigDecimal baseAmount, 
                              BigDecimal discountAmount, BigDecimal taxAmount, BigDecimal penaltyAmount, 
                              BigDecimal totalAmount) {
        this.durationMinutes = durationMinutes;
        this.durationFormatted = durationFormatted;
        this.baseAmount = baseAmount;
        this.discountAmount = discountAmount;
        this.taxAmount = taxAmount;
        this.penaltyAmount = penaltyAmount;
        this.totalAmount = totalAmount;
    }

    public Long getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(Long durationMinutes) { this.durationMinutes = durationMinutes; }

    public String getDurationFormatted() { return durationFormatted; }
    public void setDurationFormatted(String durationFormatted) { this.durationFormatted = durationFormatted; }

    public BigDecimal getBaseAmount() { return baseAmount; }
    public void setBaseAmount(BigDecimal baseAmount) { this.baseAmount = baseAmount; }

    public BigDecimal getDiscountAmount() { return discountAmount; }
    public void setDiscountAmount(BigDecimal discountAmount) { this.discountAmount = discountAmount; }

    public BigDecimal getTaxAmount() { return taxAmount; }
    public void setTaxAmount(BigDecimal taxAmount) { this.taxAmount = taxAmount; }

    public BigDecimal getPenaltyAmount() { return penaltyAmount; }
    public void setPenaltyAmount(BigDecimal penaltyAmount) { this.penaltyAmount = penaltyAmount; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
}
