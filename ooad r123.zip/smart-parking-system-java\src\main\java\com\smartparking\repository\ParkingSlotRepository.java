package com.smartparking.repository;

import com.smartparking.entity.ParkingSlot;
import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ParkingSlotRepository extends JpaRepository<ParkingSlot, Long> {
    Optional<ParkingSlot> findBySlotNumber(String slotNumber);
    List<ParkingSlot> findByCategory(VehicleCategory category);
    List<ParkingSlot> findByStatus(SlotStatus status);
    List<ParkingSlot> findByCategoryAndStatus(VehicleCategory category, SlotStatus status);
    List<ParkingSlot> findByCategoryAndStatusOrderByWalkDistanceUnitsAsc(VehicleCategory category, SlotStatus status);

    long countByStatus(SlotStatus status);
    long countByCategory(VehicleCategory category);
    long countByCategoryAndStatus(VehicleCategory category, SlotStatus status);
}
