package com.smartparking.entity;

import com.smartparking.enums.BillingPlan;
import com.smartparking.enums.VehicleCategory;
import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "parking_sessions", indexes = {
    @Index(name = "idx_session_ticket", columnList = "ticket_number", unique = true),
    @Index(name = "idx_session_vehicle", columnList = "vehicle_number, status")
})
public class ParkingSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ticket_number", nullable = false, unique = true, length = 50)
    private String ticketNumber;

    @Column(name = "vehicle_number", nullable = false, length = 30)
    private String vehicleNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private VehicleCategory category;

    @Column(name = "customer_name", nullable = false, length = 100)
    private String customerName;

    @Column(name = "customer_phone", nullable = false, length = 25)
    private String customerPhone;

    @Column(name = "slot_id", nullable = false)
    private Long slotId;

    @Column(name = "slot_number", nullable = false, length = 20)
    private String slotNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "billing_plan", nullable = false, length = 20)
    private BillingPlan billingPlan = BillingPlan.HOURLY;

    @Column(name = "entry_time", nullable = false)
    private LocalDateTime entryTime = LocalDateTime.now();

    @Column(name = "exit_time")
    private LocalDateTime exitTime;

    @Column(name = "duration_minutes")
    private Long durationMinutes = 0L;

    // IMMUTABLE PRICING SNAPSHOT (Guarantees active sessions are never repriced)
    @Column(name = "snapshot_hourly_rate", precision = 10, scale = 2)
    private BigDecimal snapshotHourlyRate;

    @Column(name = "snapshot_daily_rate", precision = 10, scale = 2)
    private BigDecimal snapshotDailyRate;

    @Column(name = "snapshot_grace_minutes")
    private Integer snapshotGraceMinutes = 15;

    @Column(name = "snapshot_overtime_rate", precision = 10, scale = 2)
    private BigDecimal snapshotOvertimeRate;

    @Column(name = "snapshot_tax_percent")
    private Double snapshotTaxPercent = 18.0;

    // Monetary Calculation Fields
    @Column(name = "base_amount", precision = 10, scale = 2)
    private BigDecimal baseAmount = BigDecimal.ZERO;

    @Column(name = "discount_amount", precision = 10, scale = 2)
    private BigDecimal discountAmount = BigDecimal.ZERO;

    @Column(name = "tax_amount", precision = 10, scale = 2)
    private BigDecimal taxAmount = BigDecimal.ZERO;

    @Column(name = "penalty_amount", precision = 10, scale = 2)
    private BigDecimal penaltyAmount = BigDecimal.ZERO;

    @Column(name = "total_amount", precision = 10, scale = 2)
    private BigDecimal totalAmount = BigDecimal.ZERO;

    @Column(nullable = false, length = 20)
    private String status = "ACTIVE"; // ACTIVE, COMPLETED, CANCELLED

    @Column(name = "payment_status", length = 20)
    private String paymentStatus = "UNPAID"; // UNPAID, PAID

    @Lob
    @Column(name = "qr_code_base64")
    private String qrCodeBase64;

    @Column(name = "has_active_pass")
    private Boolean hasActivePass = false;

    public ParkingSession() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTicketNumber() { return ticketNumber; }
    public void setTicketNumber(String ticketNumber) { this.ticketNumber = ticketNumber; }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public VehicleCategory getCategory() { return category; }
    public void setCategory(VehicleCategory category) { this.category = category; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    public Long getSlotId() { return slotId; }
    public void setSlotId(Long slotId) { this.slotId = slotId; }

    public String getSlotNumber() { return slotNumber; }
    public void setSlotNumber(String slotNumber) { this.slotNumber = slotNumber; }

    public BillingPlan getBillingPlan() { return billingPlan; }
    public void setBillingPlan(BillingPlan billingPlan) { this.billingPlan = billingPlan; }

    public LocalDateTime getEntryTime() { return entryTime; }
    public void setEntryTime(LocalDateTime entryTime) { this.entryTime = entryTime; }

    public LocalDateTime getExitTime() { return exitTime; }
    public void setExitTime(LocalDateTime exitTime) { this.exitTime = exitTime; }

    public Long getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(Long durationMinutes) { this.durationMinutes = durationMinutes; }

    public BigDecimal getSnapshotHourlyRate() { return snapshotHourlyRate; }
    public void setSnapshotHourlyRate(BigDecimal snapshotHourlyRate) { this.snapshotHourlyRate = snapshotHourlyRate; }

    public BigDecimal getSnapshotDailyRate() { return snapshotDailyRate; }
    public void setSnapshotDailyRate(BigDecimal snapshotDailyRate) { this.snapshotDailyRate = snapshotDailyRate; }

    public Integer getSnapshotGraceMinutes() { return snapshotGraceMinutes; }
    public void setSnapshotGraceMinutes(Integer snapshotGraceMinutes) { this.snapshotGraceMinutes = snapshotGraceMinutes; }

    public BigDecimal getSnapshotOvertimeRate() { return snapshotOvertimeRate; }
    public void setSnapshotOvertimeRate(BigDecimal snapshotOvertimeRate) { this.snapshotOvertimeRate = snapshotOvertimeRate; }

    public Double getSnapshotTaxPercent() { return snapshotTaxPercent; }
    public void setSnapshotTaxPercent(Double snapshotTaxPercent) { this.snapshotTaxPercent = snapshotTaxPercent; }

    public BigDecimal getBaseAmount() { return baseAmount; }
    public void setBaseAmount(BigDecimal baseAmount) { this.baseAmount = baseAmount; }

    public BigDecimal getDiscountAmount() { return discountAmount; }
    public void setDiscountAmount(BigDecimal discountAmount) { this.discountAmount = discountAmount; }

    public BigDecimal getTaxAmount() { return taxAmount; }
    public void setTaxAmount(BigDecimal taxAmount) { this.taxAmount = taxAmount; }

    public BigDecimal getPenaltyAmount() { return penaltyAmount; }
    public void setPenaltyAmount(BigDecimal penaltyAmount) { this.penaltyAmount = penaltyAmount; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getQrCodeBase64() { return qrCodeBase64; }
    public void setQrCodeBase64(String qrCodeBase64) { this.qrCodeBase64 = qrCodeBase64; }

    public Boolean getHasActivePass() { return hasActivePass; }
    public void setHasActivePass(Boolean hasActivePass) { this.hasActivePass = hasActivePass; }
}
