package com.smartparking.config;

import com.smartparking.entity.*;
import com.smartparking.enums.*;
import com.smartparking.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
public class DatabaseInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ParkingZoneRepository zoneRepository;

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private PricingRuleRepository pricingRuleRepository;

    @Autowired
    private ParkingSessionRepository sessionRepository;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Override
    public void run(String... args) {
        System.out.println("[DatabaseInitializer] Initializing Smart Parking System Data...");

        if (userRepository.count() > 0) {
            System.out.println("[DatabaseInitializer] Existing database records detected. Skipping initial seed.");
            return;
        }

        // 1. Seed Multi-User Accounts with Dedicated Admin
        userRepository.save(new User("Facility Administrator", "admin@smartparking.com", "admin123", UserRole.SUPER_ADMIN, "+91 9876543210"));
        userRepository.save(new User("Super Administrator", "admin@parking.com", "Admin@12345", UserRole.SUPER_ADMIN, "+91 9876543210"));
        userRepository.save(new User("Operations Manager", "manager@parking.com", "Admin@12345", UserRole.PARKING_MANAGER, "+91 9876543211"));
        userRepository.save(new User("Booth Gate Staff", "staff@parking.com", "Admin@12345", UserRole.PARKING_STAFF, "+91 9876543212"));
        userRepository.save(new User("Senior Accountant", "accountant@parking.com", "Admin@12345", UserRole.ACCOUNTANT, "+91 9876543213"));
        userRepository.save(new User("Rajesh Sharma", "customer@parking.com", "Customer@12345", UserRole.CUSTOMER, "+91 9876543214"));

        // 2. Seed Pricing Tariffs for all 4 vehicle categories matching project requirements in INR
        pricingRuleRepository.save(new PricingRule(VehicleCategory.TWO_WHEELER, BigDecimal.valueOf(10.0), BigDecimal.valueOf(60.0), BigDecimal.valueOf(900.0), BigDecimal.valueOf(9000.0), 15, BigDecimal.valueOf(15.0), 18.0));
        pricingRuleRepository.save(new PricingRule(VehicleCategory.FOUR_WHEELER, BigDecimal.valueOf(30.0), BigDecimal.valueOf(180.0), BigDecimal.valueOf(3000.0), BigDecimal.valueOf(30000.0), 15, BigDecimal.valueOf(45.0), 18.0));
        pricingRuleRepository.save(new PricingRule(VehicleCategory.COMMERCIAL, BigDecimal.valueOf(50.0), BigDecimal.valueOf(300.0), BigDecimal.valueOf(5000.0), BigDecimal.valueOf(50000.0), 15, BigDecimal.valueOf(75.0), 18.0));
        pricingRuleRepository.save(new PricingRule(VehicleCategory.HEAVY, BigDecimal.valueOf(80.0), BigDecimal.valueOf(500.0), BigDecimal.valueOf(8000.0), BigDecimal.valueOf(80000.0), 15, BigDecimal.valueOf(120.0), 18.0));

        // 3. Seed Zones
        ParkingZone zoneA = zoneRepository.save(new ParkingZone("Zone A - Two-Wheeler Bay", "ZONE_A", "Basement 1", VehicleCategory.TWO_WHEELER, 10));
        ParkingZone zoneB = zoneRepository.save(new ParkingZone("Zone B - Four-Wheeler Standard & EV", "ZONE_B", "Ground Floor", VehicleCategory.FOUR_WHEELER, 20));
        ParkingZone zoneC = zoneRepository.save(new ParkingZone("Zone C - Commercial Logistics Bay", "ZONE_C", "East Wing", VehicleCategory.COMMERCIAL, 10));
        ParkingZone zoneD = zoneRepository.save(new ParkingZone("Zone D - Heavy Vehicle Terminus", "ZONE_D", "North Surface Yard", VehicleCategory.HEAVY, 5));

        // 4. Seed 45 Parking Slots with unique slot IDs
        // Two-Wheelers: B01 to B10
        for (int i = 1; i <= 10; i++) {
            String slotNumber = String.format("B%02d", i);
            SlotStatus st = (i == 1) ? SlotStatus.OCCUPIED : ((i == 2) ? SlotStatus.RESERVED : ((i == 10) ? SlotStatus.MAINTENANCE : SlotStatus.AVAILABLE));
            ParkingSlot s = new ParkingSlot(slotNumber, zoneA, VehicleCategory.TWO_WHEELER, st, 2.5, 1.2, (i <= 2), i * 3);
            if (i == 1) s.setAssignedVehiclePlate("MH12AB1234");
            if (i == 2) s.setAssignedVehiclePlate("MH12XY9999");
            slotRepository.save(s);
        }

        // Four-Wheelers: C01 to C20
        for (int i = 1; i <= 20; i++) {
            String slotNumber = String.format("C%02d", i);
            SlotStatus st = SlotStatus.AVAILABLE;
            String plate = null;
            if (i == 1) { st = SlotStatus.OCCUPIED; plate = "DL01CA2024"; }
            else if (i == 2) { st = SlotStatus.OCCUPIED; plate = "KA05MG8800"; }
            else if (i == 3) { st = SlotStatus.RESERVED; plate = "MH14EV5555"; }
            else if (i == 19) { st = SlotStatus.MAINTENANCE; }
            else if (i == 20) { st = SlotStatus.DISABLED; }

            ParkingSlot s = new ParkingSlot(slotNumber, zoneB, VehicleCategory.FOUR_WHEELER, st, 5.0, 2.4, (i <= 4), i * 2);
            s.setAssignedVehiclePlate(plate);
            slotRepository.save(s);
        }

        // Commercial: CM01 to CM10
        for (int i = 1; i <= 10; i++) {
            String slotNumber = String.format("CM%02d", i);
            SlotStatus st = (i == 1) ? SlotStatus.OCCUPIED : ((i == 9) ? SlotStatus.MAINTENANCE : SlotStatus.AVAILABLE);
            ParkingSlot s = new ParkingSlot(slotNumber, zoneC, VehicleCategory.COMMERCIAL, st, 6.5, 2.8, false, i * 4);
            if (i == 1) s.setAssignedVehiclePlate("MH04CM7001");
            slotRepository.save(s);
        }

        // Heavy: HV01 to HV05
        for (int i = 1; i <= 5; i++) {
            String slotNumber = String.format("HV%02d", i);
            SlotStatus st = (i == 1) ? SlotStatus.OCCUPIED : SlotStatus.AVAILABLE;
            ParkingSlot s = new ParkingSlot(slotNumber, zoneD, VehicleCategory.HEAVY, st, 12.0, 3.2, false, i * 5);
            if (i == 1) s.setAssignedVehiclePlate("KA01HV9000");
            slotRepository.save(s);
        }

        // 5. Seed Active Sessions
        createSampleSession("TKT-20261021-1001", "MH12AB1234", VehicleCategory.TWO_WHEELER, "Amit Verma", "+91 9822012345", "B01", BillingPlan.HOURLY, 150L, BigDecimal.valueOf(10.0));
        createSampleSession("TKT-20261021-1002", "DL01CA2024", VehicleCategory.FOUR_WHEELER, "Priya Sundaram", "+91 9911022334", "C01", BillingPlan.HOURLY, 240L, BigDecimal.valueOf(30.0));
        createSampleSession("TKT-20261021-1003", "KA05MG8800", VehicleCategory.FOUR_WHEELER, "Karthik Rao", "+91 9845012345", "C02", BillingPlan.DAILY, 800L, BigDecimal.valueOf(30.0));

        // 6. Seed Completed Payments
        createSamplePayment("TXN-20261021-001", "DL04BB1122", "Anil Kapoor", BigDecimal.valueOf(90.00), BigDecimal.valueOf(16.20), BigDecimal.valueOf(106.20), PaymentMethod.UPI);
        createSamplePayment("TXN-20261021-002", "GJ01CD3344", "Sneha Patel", BigDecimal.valueOf(180.00), BigDecimal.valueOf(32.40), BigDecimal.valueOf(212.40), PaymentMethod.CARD);
        createSamplePayment("TXN-20261021-003", "KA04MN7788", "Rahul Dravid", BigDecimal.valueOf(300.00), BigDecimal.valueOf(54.00), BigDecimal.valueOf(354.00), PaymentMethod.ONLINE_GATEWAY);

        // 7. Seed Operating Expenses
        expenseRepository.save(new Expense("Facility Power Bill - Oct 2026", ExpenseCategory.ELECTRICITY, BigDecimal.valueOf(14500.00), "BESCOM Monthly electricity utility", "BANK_TRANSFER", "BESCOM-9081"));
        expenseRepository.save(new Expense("Boom Barrier Sensor Loop Repair", ExpenseCategory.EQUIPMENT, BigDecimal.valueOf(6800.00), "Replaced optical vehicle sensor at Lane 1", "CARD", "INV-BARRIER-44"));
        expenseRepository.save(new Expense("Floor Pressure Wash & Cleaning", ExpenseCategory.CLEANING, BigDecimal.valueOf(3200.00), "Zone A & Zone B degreasing", "CASH", "CLEAN-WK-42"));

        // 8. Seed Audit Log
        auditLogRepository.save(new AuditLog("FACILITY_INITIALIZED", "SYSTEM", "FACILITY_01", null, "45 Bays Ready", "Initial system configuration and bay provisioning", "Super Administrator", "SUPER_ADMIN"));

        System.out.println("[DatabaseInitializer] Database initialization completed successfully with 45 bays & initial tariffs!");
    }

    private void createSampleSession(String ticket, String plate, VehicleCategory cat, String name, String phone, String slotNo, BillingPlan plan, Long minsAgo, BigDecimal hourlyRate) {
        ParkingSession session = new ParkingSession();
        session.setTicketNumber(ticket);
        session.setVehicleNumber(plate);
        session.setCategory(cat);
        session.setCustomerName(name);
        session.setCustomerPhone(phone);
        session.setSlotId(1L);
        session.setSlotNumber(slotNo);
        session.setBillingPlan(plan);
        session.setEntryTime(LocalDateTime.now().minusMinutes(minsAgo));
        session.setStatus("ACTIVE");
        session.setPaymentStatus("UNPAID");
        session.setSnapshotHourlyRate(hourlyRate);
        session.setSnapshotDailyRate(hourlyRate.multiply(BigDecimal.valueOf(6)));
        session.setSnapshotGraceMinutes(15);
        session.setSnapshotOvertimeRate(hourlyRate.multiply(BigDecimal.valueOf(1.5)));
        session.setSnapshotTaxPercent(18.0);
        sessionRepository.save(session);
    }

    private void createSamplePayment(String txnId, String plate, String name, BigDecimal base, BigDecimal tax, BigDecimal total, PaymentMethod method) {
        Payment p = new Payment();
        p.setTransactionId(txnId);
        p.setVehicleNumber(plate);
        p.setCustomerName(name);
        p.setBaseAmount(base);
        p.setTaxAmount(tax);
        p.setTotalAmount(total);
        p.setPaymentMethod(method);
        p.setStatus(PaymentStatus.PAID);
        paymentRepository.save(p);
    }
}
