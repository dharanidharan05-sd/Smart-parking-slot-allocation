package com.smartparking.dto;

import java.math.BigDecimal;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class PricingUpdateRequest {

    @NotNull(message = "Hourly rate is required")
    private BigDecimal hourlyRate;

    @NotNull(message = "Daily rate is required")
    private BigDecimal dailyRate;

    @NotNull(message = "Monthly rate is required")
    private BigDecimal monthlyRate;

    @NotNull(message = "Yearly rate is required")
    private BigDecimal yearlyRate;

    private Integer gracePeriodMinutes = 15;

    @NotNull(message = "Overtime rate is required")
    private BigDecimal overtimeRatePerHour;

    private Double taxPercent = 18.0;

    @NotBlank(message = "A justification reason is required for the audit log")
    private String reason;

    private String updatedBy = "Administrator";

    public PricingUpdateRequest() {}

    public BigDecimal getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(BigDecimal hourlyRate) { this.hourlyRate = hourlyRate; }

    public BigDecimal getDailyRate() { return dailyRate; }
    public void setDailyRate(BigDecimal dailyRate) { this.dailyRate = dailyRate; }

    public BigDecimal getMonthlyRate() { return monthlyRate; }
    public void setMonthlyRate(BigDecimal monthlyRate) { this.monthlyRate = monthlyRate; }

    public BigDecimal getYearlyRate() { return yearlyRate; }
    public void setYearlyRate(BigDecimal yearlyRate) { this.yearlyRate = yearlyRate; }

    public Integer getGracePeriodMinutes() { return gracePeriodMinutes; }
    public void setGracePeriodMinutes(Integer gracePeriodMinutes) { this.gracePeriodMinutes = gracePeriodMinutes; }

    public BigDecimal getOvertimeRatePerHour() { return overtimeRatePerHour; }
    public void setOvertimeRatePerHour(BigDecimal overtimeRatePerHour) { this.overtimeRatePerHour = overtimeRatePerHour; }

    public Double getTaxPercent() { return taxPercent; }
    public void setTaxPercent(Double taxPercent) { this.taxPercent = taxPercent; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }
}
