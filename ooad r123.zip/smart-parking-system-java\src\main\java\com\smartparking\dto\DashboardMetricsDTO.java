package com.smartparking.dto;

import java.math.BigDecimal;
import java.util.Map;

public class DashboardMetricsDTO {
    private long totalSlots;
    private long availableSlots;
    private long occupiedSlots;
    private long reservedSlots;
    private long maintenanceSlots;
    private long disabledSlots;
    private long activeSessions;
    private BigDecimal todayCollections;
    private BigDecimal monthlyRevenue;
    private BigDecimal totalExpenses;
    private BigDecimal netOperatingProfit;
    private Map<String, Object> categoryOccupancy;

    public DashboardMetricsDTO() {}

    public long getTotalSlots() { return totalSlots; }
    public void setTotalSlots(long totalSlots) { this.totalSlots = totalSlots; }

    public long getAvailableSlots() { return availableSlots; }
    public void setAvailableSlots(long availableSlots) { this.availableSlots = availableSlots; }

    public long getOccupiedSlots() { return occupiedSlots; }
    public void setOccupiedSlots(long occupiedSlots) { this.occupiedSlots = occupiedSlots; }

    public long getReservedSlots() { return reservedSlots; }
    public void setReservedSlots(long reservedSlots) { this.reservedSlots = reservedSlots; }

    public long getMaintenanceSlots() { return maintenanceSlots; }
    public void setMaintenanceSlots(long maintenanceSlots) { this.maintenanceSlots = maintenanceSlots; }

    public long getDisabledSlots() { return disabledSlots; }
    public void setDisabledSlots(long disabledSlots) { this.disabledSlots = disabledSlots; }

    public long getActiveSessions() { return activeSessions; }
    public void setActiveSessions(long activeSessions) { this.activeSessions = activeSessions; }

    public BigDecimal getTodayCollections() { return todayCollections; }
    public void setTodayCollections(BigDecimal todayCollections) { this.todayCollections = todayCollections; }

    public BigDecimal getMonthlyRevenue() { return monthlyRevenue; }
    public void setMonthlyRevenue(BigDecimal monthlyRevenue) { this.monthlyRevenue = monthlyRevenue; }

    public BigDecimal getTotalExpenses() { return totalExpenses; }
    public void setTotalExpenses(BigDecimal totalExpenses) { this.totalExpenses = totalExpenses; }

    public BigDecimal getNetOperatingProfit() { return netOperatingProfit; }
    public void setNetOperatingProfit(BigDecimal netOperatingProfit) { this.netOperatingProfit = netOperatingProfit; }

    public Map<String, Object> getCategoryOccupancy() { return categoryOccupancy; }
    public void setCategoryOccupancy(Map<String, Object> categoryOccupancy) { this.categoryOccupancy = categoryOccupancy; }
}
