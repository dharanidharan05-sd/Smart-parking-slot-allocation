package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.entity.ParkingSlot;
import com.smartparking.entity.ParkingZone;
import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.repository.ParkingSlotRepository;
import com.smartparking.repository.ParkingZoneRepository;
import com.smartparking.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/parking")
@CrossOrigin(origins = "*")
public class ParkingSlotController {

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private ParkingZoneRepository zoneRepository;

    @Autowired
    private AuditService auditService;

    @GetMapping("/layout")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getVisualLayout(
            @RequestParam(required = false) VehicleCategory category,
            @RequestParam(required = false) SlotStatus status) {

        List<ParkingSlot> slots;
        if (category != null && status != null) {
            slots = slotRepository.findByCategoryAndStatus(category, status);
        } else if (category != null) {
            slots = slotRepository.findByCategory(category);
        } else if (status != null) {
            slots = slotRepository.findByStatus(status);
        } else {
            slots = slotRepository.findAll();
        }

        List<ParkingZone> zones = zoneRepository.findAll();

        Map<String, Object> data = new HashMap<>();
        data.put("slots", slots);
        data.put("zones", zones);
        data.put("totalSlots", slotRepository.count());
        return ResponseEntity.ok(ApiResponse.success(data));
    }

    @PatchMapping("/slots/{id}/status")
    public ResponseEntity<ApiResponse<ParkingSlot>> updateSlotStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        ParkingSlot slot = slotRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Parking bay not found with ID: " + id));

        String newStatusStr = body.get("status");
        String reason = body.getOrDefault("reason", "Manual bay status change");
        SlotStatus newStatus = SlotStatus.valueOf(newStatusStr);

        if (slot.getStatus() == SlotStatus.OCCUPIED && newStatus != SlotStatus.OCCUPIED) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Cannot manually change status of an OCCUPIED bay. Process checkout instead."));
        }

        SlotStatus oldStatus = slot.getStatus();
        slot.setStatus(newStatus);
        slot.setUpdatedAt(LocalDateTime.now());
        ParkingSlot updated = slotRepository.save(slot);

        auditService.logEvent("SLOT_STATUS_UPDATED", "PARKING_SLOT", slot.getSlotNumber(), oldStatus.name(), newStatus.name(), reason);
        return ResponseEntity.ok(ApiResponse.success("Bay " + slot.getSlotNumber() + " status updated to " + newStatus, updated));
    }
}
