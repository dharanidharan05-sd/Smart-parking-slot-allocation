package com.smartparking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartParkingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartParkingApplication.class, args);
        System.out.println("=======================================================================");
        System.out.println("  SMART PARKING SYSTEM (SPRING BOOT) RUNNING AT http://localhost:8080");
        System.out.println("=======================================================================");
    }
}
