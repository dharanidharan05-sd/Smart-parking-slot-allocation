package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.dto.LoginRequest;
import com.smartparking.entity.User;
import com.smartparking.enums.UserRole;
import com.smartparking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<Map<String, Object>>> login(@Valid @RequestBody LoginRequest request) {
        Optional<User> optUser = userRepository.findByEmail(request.getEmail().trim().toLowerCase());

        if (!optUser.isPresent() || !optUser.get().getPassword().equals(request.getPassword())) {
            return ResponseEntity.status(401).body(ApiResponse.error("Invalid email or password"));
        }

        User user = optUser.get();
        if (!Boolean.TRUE.equals(user.getActive())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Account is deactivated. Contact an administrator."));
        }

        Map<String, Object> data = new HashMap<>();
        data.put("id", user.getId());
        data.put("name", user.getName());
        data.put("email", user.getEmail());
        data.put("role", user.getRole().name());
        data.put("phone", user.getPhone());
        data.put("token", "sim_jwt_token_" + user.getId() + "_" + System.currentTimeMillis());

        return ResponseEntity.ok(ApiResponse.success("Authentication successful", data));
    }

    @PostMapping("/demo-login/{role}")
    public ResponseEntity<ApiResponse<Map<String, Object>>> demoLogin(@PathVariable UserRole role) {
        String email = role.name().toLowerCase() + "@parking.com";
        Optional<User> optUser = userRepository.findByEmail(email);

        if (!optUser.isPresent()) {
            return ResponseEntity.status(404).body(ApiResponse.error("Demo user not found for role: " + role));
        }

        User user = optUser.get();
        Map<String, Object> data = new HashMap<>();
        data.put("id", user.getId());
        data.put("name", user.getName());
        data.put("email", user.getEmail());
        data.put("role", user.getRole().name());
        data.put("token", "sim_jwt_token_" + user.getId() + "_" + System.currentTimeMillis());

        return ResponseEntity.ok(ApiResponse.success("Switched to demo role: " + role, data));
    }
}
