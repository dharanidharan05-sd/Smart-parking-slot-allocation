package com.smartparking.service;

import com.smartparking.entity.ParkingSlot;
import com.smartparking.entity.WaitingList;
import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.repository.ParkingSlotRepository;
import com.smartparking.repository.WaitingListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SlotAllocationService {

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private WaitingListRepository waitingListRepository;

    /**
     * Checks if slot is compatible with vehicle category and dimensions
     */
    public boolean isCompatible(ParkingSlot slot, VehicleCategory category, Double length, Double width) {
        if (slot.getCategory() != category) {
            return false;
        }
        if (slot.getStatus() != SlotStatus.AVAILABLE) {
            return false;
        }
        if (length != null && slot.getLengthMeters() != null && length > slot.getLengthMeters()) {
            return false;
        }
        if (width != null && slot.getWidthMeters() != null && width > slot.getWidthMeters()) {
            return false;
        }
        return true;
    }

    /**
     * Atomically allocates the nearest compatible available bay
     */
    @Transactional
    public ParkingSlot allocateOptimalSlot(VehicleCategory category, String vehiclePlate, Double length, Double width, Boolean preferEv) {
        List<ParkingSlot> availableSlots = slotRepository.findByCategoryAndStatusOrderByWalkDistanceUnitsAsc(category, SlotStatus.AVAILABLE);

        for (ParkingSlot slot : availableSlots) {
            if (Boolean.TRUE.equals(preferEv) && !Boolean.TRUE.equals(slot.getHasEvCharger())) {
                continue; // Skip non-EV if EV preferred
            }
            if (isCompatible(slot, category, length, width)) {
                slot.setStatus(SlotStatus.OCCUPIED);
                slot.setAssignedVehiclePlate(vehiclePlate.toUpperCase());
                slot.setUpdatedAt(LocalDateTime.now());
                return slotRepository.save(slot); // Concurrency version will increment
            }
        }

        // Fallback: if EV preferred had no matches, check standard bays
        if (Boolean.TRUE.equals(preferEv)) {
            return allocateOptimalSlot(category, vehiclePlate, length, width, false);
        }

        return null; // All compatible bays full
    }

    /**
     * Atomically allocates a specific slot chosen by operator
     */
    @Transactional
    public ParkingSlot allocateSpecificSlot(Long slotId, VehicleCategory category, String vehiclePlate, Double length, Double width) {
        ParkingSlot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> new IllegalArgumentException("Parking bay not found with ID: " + slotId));

        if (!isCompatible(slot, category, length, width)) {
            throw new IllegalStateException("Bay " + slot.getSlotNumber() + " is incompatible or not available (" + slot.getStatus() + ")");
        }

        slot.setStatus(SlotStatus.OCCUPIED);
        slot.setAssignedVehiclePlate(vehiclePlate.toUpperCase());
        slot.setUpdatedAt(LocalDateTime.now());
        return slotRepository.save(slot);
    }

    /**
     * Atomically releases a parking slot back to AVAILABLE
     */
    @Transactional
    public ParkingSlot releaseSlot(Long slotId) {
        Optional<ParkingSlot> optSlot = slotRepository.findById(slotId);
        if (!optSlot.isPresent()) return null;

        ParkingSlot slot = optSlot.get();
        slot.setStatus(SlotStatus.AVAILABLE);
        slot.setAssignedVehiclePlate(null);
        slot.setCurrentSessionId(null);
        slot.setUpdatedAt(LocalDateTime.now());
        ParkingSlot released = slotRepository.save(slot);

        // Notify next person waiting in the queue for this category
        checkAndNotifyWaitingList(slot.getCategory(), slot.getSlotNumber());

        return released;
    }

    private void checkAndNotifyWaitingList(VehicleCategory category, String slotNumber) {
        Optional<WaitingList> nextInLine = waitingListRepository.findFirstByCategoryAndStatusOrderByRequestedTimeAsc(category, "WAITING");
        if (nextInLine.isPresent()) {
            WaitingList entry = nextInLine.get();
            entry.setStatus("NOTIFIED");
            entry.setAllocatedSlotNumber(slotNumber);
            waitingListRepository.save(entry);
        }
    }
}
