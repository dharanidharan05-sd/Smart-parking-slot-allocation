package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.entity.WaitingList;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.repository.WaitingListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/waiting-list")
@CrossOrigin(origins = "*")
public class WaitingListController {

    @Autowired
    private WaitingListRepository waitingListRepository;

    @GetMapping
    public ResponseEntity<ApiResponse<List<WaitingList>>> getQueue() {
        return ResponseEntity.ok(ApiResponse.success(waitingListRepository.findByStatusOrderByRequestedTimeAsc("WAITING")));
    }

    @PostMapping("/join")
    public ResponseEntity<ApiResponse<Map<String, Object>>> joinQueue(@RequestBody WaitingList entry) {
        String cleanPlate = entry.getVehicleNumber().trim().toUpperCase();
        entry.setVehicleNumber(cleanPlate);
        entry.setRequestedTime(LocalDateTime.now());
        entry.setStatus("WAITING");

        WaitingList saved = waitingListRepository.save(entry);
        long queuePos = waitingListRepository.countByCategoryAndStatusAndRequestedTimeLessThanEqual(entry.getCategory(), "WAITING", entry.getRequestedTime());

        Map<String, Object> data = new HashMap<>();
        data.put("entry", saved);
        data.put("queuePosition", queuePos);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Vehicle " + cleanPlate + " added to queue. Position #" + queuePos, data));
    }

    @PatchMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse<WaitingList>> cancelQueueEntry(@PathVariable Long id) {
        WaitingList entry = waitingListRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Waiting entry not found with ID: " + id));

        entry.setStatus("CANCELLED");
        return ResponseEntity.ok(ApiResponse.success("Removed from waiting list", waitingListRepository.save(entry)));
    }
}
