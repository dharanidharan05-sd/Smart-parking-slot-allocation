package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.entity.Payment;
import com.smartparking.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Payment>>> getAllPayments() {
        return ResponseEntity.ok(ApiResponse.success(paymentService.getAllPayments()));
    }

    @PostMapping("/{id}/refund")
    public ResponseEntity<ApiResponse<Payment>> processRefund(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        try {
            String reason = body.get("reason");
            if (reason == null || reason.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(ApiResponse.error("A justification reason is required for refunds"));
            }
            String authorizedBy = body.getOrDefault("authorizedBy", "Senior Accountant");
            Payment refunded = paymentService.processRefund(id, reason, authorizedBy);
            return ResponseEntity.ok(ApiResponse.success("Refund authorized and logged in expense ledger", refunded));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
