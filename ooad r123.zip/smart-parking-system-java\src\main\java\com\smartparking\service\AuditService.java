package com.smartparking.service;

import com.smartparking.entity.AuditLog;
import com.smartparking.repository.AuditLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditService {

    @Autowired
    private AuditLogRepository auditLogRepository;

    public void logEvent(String action, String resourceType, String resourceId, String oldValue, String newValue, String reason) {
        AuditLog log = new AuditLog(action, resourceType, resourceId, oldValue, newValue, reason, "System Operator", "ADMIN");
        auditLogRepository.save(log);
    }

    public List<AuditLog> getRecentLogs() {
        return auditLogRepository.findTop20ByOrderByCreatedAtDesc();
    }
}
