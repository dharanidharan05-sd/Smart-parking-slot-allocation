package com.smartparking.service;

import com.smartparking.dto.DashboardMetricsDTO;
import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.repository.ExpenseRepository;
import com.smartparking.repository.ParkingSessionRepository;
import com.smartparking.repository.ParkingSlotRepository;
import com.smartparking.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class DashboardService {

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private ParkingSessionRepository sessionRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ExpenseRepository expenseRepository;

    public DashboardMetricsDTO getMetrics() {
        DashboardMetricsDTO dto = new DashboardMetricsDTO();

        dto.setTotalSlots(slotRepository.count());
        dto.setAvailableSlots(slotRepository.countByStatus(SlotStatus.AVAILABLE));
        dto.setOccupiedSlots(slotRepository.countByStatus(SlotStatus.OCCUPIED));
        dto.setReservedSlots(slotRepository.countByStatus(SlotStatus.RESERVED));
        dto.setMaintenanceSlots(slotRepository.countByStatus(SlotStatus.MAINTENANCE));
        dto.setDisabledSlots(slotRepository.countByStatus(SlotStatus.DISABLED));
        dto.setActiveSessions(sessionRepository.countByStatus("ACTIVE"));

        LocalDateTime startOfToday = LocalDate.now().atStartOfDay();
        LocalDateTime startOfMonth = LocalDate.now().withDayOfMonth(1).atStartOfDay();

        BigDecimal todayCol = paymentRepository.sumTotalPaidRevenueSince(startOfToday);
        BigDecimal monthRev = paymentRepository.sumTotalPaidRevenueSince(startOfMonth);
        BigDecimal totalRev = paymentRepository.sumTotalPaidRevenue();
        BigDecimal totalExp = expenseRepository.sumTotalExpenses();

        dto.setTodayCollections(todayCol != null ? todayCol : BigDecimal.ZERO);
        dto.setMonthlyRevenue(monthRev != null ? monthRev : BigDecimal.ZERO);
        dto.setTotalExpenses(totalExp != null ? totalExp : BigDecimal.ZERO);
        dto.setNetOperatingProfit((totalRev != null ? totalRev : BigDecimal.ZERO).subtract(totalExp != null ? totalExp : BigDecimal.ZERO));

        // Category breakdown
        Map<String, Object> catMap = new HashMap<>();
        for (VehicleCategory cat : VehicleCategory.values()) {
            long total = slotRepository.countByCategory(cat);
            long occupied = slotRepository.countByCategoryAndStatus(cat, SlotStatus.OCCUPIED);
            long available = slotRepository.countByCategoryAndStatus(cat, SlotStatus.AVAILABLE);

            Map<String, Object> stats = new HashMap<>();
            stats.put("total", total);
            stats.put("occupied", occupied);
            stats.put("available", available);
            stats.put("percentage", total > 0 ? Math.round(((double) occupied / total) * 100) : 0);
            catMap.put(cat.name(), stats);
        }
        dto.setCategoryOccupancy(catMap);

        return dto;
    }
}
