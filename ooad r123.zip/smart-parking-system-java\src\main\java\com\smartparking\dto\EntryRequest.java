package com.smartparking.dto;

import com.smartparking.enums.BillingPlan;
import com.smartparking.enums.VehicleCategory;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class EntryRequest {

    @NotBlank(message = "License plate number is required")
    private String vehicleNumber;

    @NotNull(message = "Vehicle category is required")
    private VehicleCategory category = VehicleCategory.FOUR_WHEELER;

    @NotBlank(message = "Customer name is required")
    private String customerName;

    @NotBlank(message = "Customer phone number is required")
    private String customerPhone;

    private BillingPlan billingPlan = BillingPlan.HOURLY;

    private Long slotId; // optional manual slot override

    private Boolean preferEv = false;

    private Double length;
    private Double width;

    public EntryRequest() {}

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public VehicleCategory getCategory() { return category; }
    public void setCategory(VehicleCategory category) { this.category = category; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    public BillingPlan getBillingPlan() { return billingPlan; }
    public void setBillingPlan(BillingPlan billingPlan) { this.billingPlan = billingPlan; }

    public Long getSlotId() { return slotId; }
    public void setSlotId(Long slotId) { this.slotId = slotId; }

    public Boolean getPreferEv() { return preferEv; }
    public void setPreferEv(Boolean preferEv) { this.preferEv = preferEv; }

    public Double getLength() { return length; }
    public void setLength(Double length) { this.length = length; }

    public Double getWidth() { return width; }
    public void setWidth(Double width) { this.width = width; }
}
