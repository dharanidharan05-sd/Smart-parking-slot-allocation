package com.smartparking.entity;

import com.smartparking.enums.VehicleCategory;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "waiting_list")
public class WaitingList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vehicle_number", nullable = false, length = 30)
    private String vehicleNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private VehicleCategory category;

    @Column(name = "customer_name", nullable = false, length = 100)
    private String customerName;

    @Column(name = "customer_phone", nullable = false, length = 25)
    private String customerPhone;

    @Column(name = "requested_time", nullable = false)
    private LocalDateTime requestedTime = LocalDateTime.now();

    @Column(nullable = false, length = 20)
    private String status = "WAITING"; // WAITING, NOTIFIED, ALLOCATED, CANCELLED

    @Column(name = "allocated_slot_number", length = 20)
    private String allocatedSlotNumber;

    @Column(length = 255)
    private String notes;

    public WaitingList() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public VehicleCategory getCategory() { return category; }
    public void setCategory(VehicleCategory category) { this.category = category; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    public LocalDateTime getRequestedTime() { return requestedTime; }
    public void setRequestedTime(LocalDateTime requestedTime) { this.requestedTime = requestedTime; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAllocatedSlotNumber() { return allocatedSlotNumber; }
    public void setAllocatedSlotNumber(String allocatedSlotNumber) { this.allocatedSlotNumber = allocatedSlotNumber; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
