package com.smartparking.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.smartparking.dto.EntryRequest;
import com.smartparking.dto.ExitCalculationDTO;
import com.smartparking.dto.ExitCheckoutRequest;
import com.smartparking.entity.*;
import com.smartparking.enums.PaymentStatus;
import com.smartparking.enums.SlotStatus;
import com.smartparking.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class EntryExitService {

    @Autowired
    private ParkingSessionRepository sessionRepository;

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private PricingRuleRepository pricingRuleRepository;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private SlotAllocationService slotAllocationService;

    @Autowired
    private PricingEngineService pricingEngineService;

    @Autowired
    private AuditService auditService;

    /**
     * Generates a Base64 encoded QR Code data URL using ZXing
     */
    public String generateQRCodeBase64(String content) {
        try {
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, 200, 200);
            ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream);
            byte[] pngData = pngOutputStream.toByteArray();
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(pngData);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Registers vehicle entry, allocates bay atomically, captures immutable price snapshot, and issues QR ticket
     */
    @Transactional
    public Map<String, Object> registerVehicleEntry(EntryRequest request) {
        String cleanPlate = request.getVehicleNumber().trim().toUpperCase();

        // 1. Verify vehicle doesn't already have an active inside session
        Optional<ParkingSession> activeSession = sessionRepository.findByVehicleNumberAndStatus(cleanPlate, "ACTIVE");
        if (activeSession.isPresent()) {
            throw new IllegalStateException("Vehicle " + cleanPlate + " already has an active entry in Bay " + activeSession.get().getSlotNumber());
        }

        // 2. Check for active recurring subscription pass
        Optional<Subscription> activePass = subscriptionRepository.findByVehicleNumberAndCategoryAndStatusAndEndDateAfter(
                cleanPlate, request.getCategory(), "ACTIVE", LocalDateTime.now()
        );

        // 3. Capture Pricing Snapshot
        PricingRule rule = pricingRuleRepository.findByCategory(request.getCategory())
                .orElseThrow(() -> new IllegalArgumentException("Pricing tariff rule not configured for: " + request.getCategory()));

        // 4. Allocate Parking Slot
        ParkingSlot allocatedSlot;
        if (request.getSlotId() != null) {
            allocatedSlot = slotAllocationService.allocateSpecificSlot(
                    request.getSlotId(), request.getCategory(), cleanPlate, request.getLength(), request.getWidth()
            );
        } else {
            allocatedSlot = slotAllocationService.allocateOptimalSlot(
                    request.getCategory(), cleanPlate, request.getLength(), request.getWidth(), request.getPreferEv()
            );
        }

        if (allocatedSlot == null) {
            throw new IllegalStateException("No compatible " + request.getCategory() + " bays are currently available. Please join the waiting queue.");
        }

        // 5. Generate Ticket Number & QR Code
        String datePart = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int randSuffix = (int) (1000 + Math.random() * 9000);
        String ticketNumber = "TKT-" + datePart + "-" + randSuffix;

        String qrPayload = "TICKET:" + ticketNumber + "|PLATE:" + cleanPlate + "|BAY:" + allocatedSlot.getSlotNumber() + "|TIME:" + LocalDateTime.now();
        String qrCodeBase64 = generateQRCodeBase64(qrPayload);

        // 6. Create Session
        ParkingSession session = new ParkingSession();
        session.setTicketNumber(ticketNumber);
        session.setVehicleNumber(cleanPlate);
        session.setCategory(request.getCategory());
        session.setCustomerName(request.getCustomerName().trim());
        session.setCustomerPhone(request.getCustomerPhone().trim());
        session.setSlotId(allocatedSlot.getId());
        session.setSlotNumber(allocatedSlot.getSlotNumber());
        session.setBillingPlan(request.getBillingPlan());
        session.setEntryTime(LocalDateTime.now());
        session.setStatus("ACTIVE");
        session.setPaymentStatus(activePass.isPresent() ? "PAID" : "UNPAID");
        session.setHasActivePass(activePass.isPresent());
        session.setQrCodeBase64(qrCodeBase64);

        // IMMUTABLE SNAPSHOT
        session.setSnapshotHourlyRate(rule.getHourlyRate());
        session.setSnapshotDailyRate(rule.getDailyRate());
        session.setSnapshotGraceMinutes(rule.getGracePeriodMinutes());
        session.setSnapshotOvertimeRate(rule.getOvertimeRatePerHour());
        session.setSnapshotTaxPercent(rule.getTaxPercent());

        ParkingSession savedSession = sessionRepository.save(session);

        // Link slot to session
        allocatedSlot.setCurrentSessionId(savedSession.getId());
        slotRepository.save(allocatedSlot);

        // Audit log
        auditService.logEvent("VEHICLE_ENTRY", "PARKING_SESSION", ticketNumber, null, cleanPlate + " in " + allocatedSlot.getSlotNumber(), "Vehicle entry registered");

        Map<String, Object> result = new HashMap<>();
        result.put("session", savedSession);
        result.put("ticketNumber", ticketNumber);
        result.put("slotNumber", allocatedSlot.getSlotNumber());
        result.put("qrCodeBase64", qrCodeBase64);
        result.put("hasPass", activePass.isPresent());
        return result;
    }

    /**
     * Preview fee breakdown for checkout by ticket or license plate
     */
    public Map<String, Object> previewCheckout(String identifier) {
        String cleanId = identifier.trim().toUpperCase();

        ParkingSession session = sessionRepository.findByTicketNumber(cleanId)
                .orElseGet(() -> sessionRepository.findByVehicleNumberAndStatus(cleanId, "ACTIVE")
                .orElseGet(() -> sessionRepository.findBySlotNumberAndStatus(cleanId, "ACTIVE")
                .orElseThrow(() -> new IllegalArgumentException("No active parking session found matching: " + cleanId))));

        ExitCalculationDTO calculation = pricingEngineService.calculateFee(session, LocalDateTime.now(), 0.0);

        Map<String, Object> res = new HashMap<>();
        res.put("session", session);
        res.put("feeBreakdown", calculation);
        return res;
    }

    /**
     * Processes exit checkout, records payment, completes session, releases slot, and generates tax receipt
     */
    @Transactional
    public Map<String, Object> processVehicleExit(ExitCheckoutRequest request) {
        String ticketNumber = request.getTicketNumber().trim().toUpperCase();

        ParkingSession session = sessionRepository.findByTicketNumber(ticketNumber)
                .orElseThrow(() -> new IllegalArgumentException("Active session not found for ticket: " + ticketNumber));

        if (!"ACTIVE".equals(session.getStatus())) {
            throw new IllegalStateException("Session for ticket " + ticketNumber + " is already " + session.getStatus());
        }

        LocalDateTime exitTime = LocalDateTime.now();
        ExitCalculationDTO calculation = pricingEngineService.calculateFee(session, exitTime, request.getCustomDiscountPercent());

        // Generate Transaction ID
        String datePart = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int randTxn = (int) (100000 + Math.random() * 900000);
        String transactionId = "TXN-" + datePart + "-" + randTxn;

        // Record Payment
        Payment payment = new Payment();
        payment.setTransactionId(transactionId);
        payment.setTicketNumber(session.getTicketNumber());
        payment.setVehicleNumber(session.getVehicleNumber());
        payment.setCustomerName(session.getCustomerName());
        payment.setCustomerPhone(session.getCustomerPhone());
        payment.setBaseAmount(calculation.getBaseAmount());
        payment.setDiscountAmount(calculation.getDiscountAmount());
        payment.setTaxAmount(calculation.getTaxAmount());
        payment.setPenaltyAmount(calculation.getPenaltyAmount());
        payment.setTotalAmount(calculation.getTotalAmount());
        payment.setPaymentMethod(request.getPaymentMethod());
        payment.setStatus(PaymentStatus.PAID);
        Payment savedPayment = paymentRepository.save(payment);

        // Update Session
        session.setExitTime(exitTime);
        session.setDurationMinutes(calculation.getDurationMinutes());
        session.setBaseAmount(calculation.getBaseAmount());
        session.setDiscountAmount(calculation.getDiscountAmount());
        session.setTaxAmount(calculation.getTaxAmount());
        session.setPenaltyAmount(calculation.getPenaltyAmount());
        session.setTotalAmount(calculation.getTotalAmount());
        session.setStatus("COMPLETED");
        session.setPaymentStatus("PAID");
        sessionRepository.save(session);

        // Atomically release parking bay back to AVAILABLE
        slotAllocationService.releaseSlot(session.getSlotId());

        // Audit Log
        auditService.logEvent("VEHICLE_EXIT", "PARKING_SESSION", ticketNumber, "ACTIVE", "COMPLETED", "Exit processed, bay " + session.getSlotNumber() + " cleared");

        Map<String, Object> receipt = new HashMap<>();
        receipt.put("receiptNumber", transactionId);
        receipt.put("ticketNumber", session.getTicketNumber());
        receipt.put("vehicleNumber", session.getVehicleNumber());
        receipt.put("category", session.getCategory().name());
        receipt.put("customerName", session.getCustomerName());
        receipt.put("customerPhone", session.getCustomerPhone());
        receipt.put("slotNumber", session.getSlotNumber());
        receipt.put("entryTime", session.getEntryTime());
        receipt.put("exitTime", exitTime);
        receipt.put("durationFormatted", calculation.getDurationFormatted());
        receipt.put("baseAmount", calculation.getBaseAmount());
        receipt.put("discountAmount", calculation.getDiscountAmount());
        receipt.put("taxAmount", calculation.getTaxAmount());
        receipt.put("penaltyAmount", calculation.getPenaltyAmount());
        receipt.put("totalAmount", calculation.getTotalAmount());
        receipt.put("paymentMethod", request.getPaymentMethod().name());

        Map<String, Object> response = new HashMap<>();
        response.put("receipt", receipt);
        response.put("payment", savedPayment);
        return response;
    }
}
