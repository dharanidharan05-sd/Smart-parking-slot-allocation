/**
 * Smart Parking System - Application Logic
 * Supports 4 Floors, Incoming/Outgoing Tracking, Dynamic Hourly Billing, and Live Green/Red/Yellow Grid
 */

const state = {
  currentView: 'home',
  currentFloor: 0,
  selectedVehicleType: 'FOUR_WHEELER',
  selectedPaymentMethod: 'UPI',
  slots: [],
  currentBill: null,
  activePlanType: 'hour',
  activePlanValue: 1,
  simulatedMinutes: null,
  adminLoggedIn: false
};

const defaultTariffs = {
  FOUR_WHEELER: 50.0,
  TWO_WHEELER: 20.0,
  EV: 60.0,
  HEAVY_VEHICLE: 80.0
};

document.addEventListener('DOMContentLoaded', () => {
  setupHashRouting();
  initLiveClock();
  refreshAllData();
  updateBookingVehicleRates();
  setInterval(refreshAllData, 15000);
});

function initLiveClock() {
  const clockEl = document.getElementById('liveClockDisplay');
  if (!clockEl) return;
  function tick() {
    const now = new Date();
    clockEl.innerText = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
  tick();
  setInterval(tick, 1000);
}

function setupHashRouting() {
  const hash = window.location.hash.replace('#', '') || 'home';
  navigateTo(hash);

  window.addEventListener('hashchange', () => {
    const newHash = window.location.hash.replace('#', '') || 'home';
    navigateTo(newHash);
  });
}

function navigateTo(viewId) {
  state.currentView = viewId;

  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.view === viewId);
  });

  // Update mobile bottom bar active state
  document.querySelectorAll('.mobile-nav-item').forEach(item => {
    item.classList.remove('active');
  });
  const activeMob = document.getElementById(`mobNav${viewId.charAt(0).toUpperCase() + viewId.slice(1)}`);
  if (activeMob) activeMob.classList.add('active');

  document.querySelectorAll('.view-section').forEach(sec => {
    sec.classList.remove('active');
  });

  const activeSection = document.getElementById(`view-${viewId}`);
  if (activeSection) {
    activeSection.classList.add('active');
  }

  if (viewId === 'home') {
    renderHomeTrafficTables();
    if (state.slots && state.slots.length > 0) updateFloorMonitors(state.slots);
    updateNearestSlotRecommendation();
  } else if (viewId === 'slots') {
    renderSlotsGrid();
    updateNearestSlotRecommendation();
  } else if (viewId === 'book') {
    populateManualSlotDropdown();
    updateTicketPreview();
    updateNearestSlotRecommendation();
    updateBookingVehicleRates();
  } else if (viewId === 'payment') {
    loadQuickCarChips();
  } else if (viewId === 'admin') {
    if (state.adminLoggedIn) {
      loadAdminData();
    }
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// =====================================================================
// DATA & TRAFFIC METRICS (INCOMING & OUTGOING)
// =====================================================================
async function refreshAllData() {
  try {
    state.slots = await ApiClient.getSlots();
    const stats = await ApiClient.getAdminStats();
    updateTrafficSummary(stats, state.slots);
    updateFloorMonitors(state.slots);
    renderSlotsGrid();
    updateNearestSlotRecommendation();
    loadQuickCarChips();
    renderHomeTrafficTables();
  } catch (err) {
    console.error('Data refresh error:', err);
  }
}

function updateTrafficSummary(stats, slots) {
  const total = slots.length;
  const available = slots.filter(s => s.status === 'AVAILABLE').length;
  const occupied = slots.filter(s => s.status === 'OCCUPIED').length;

  setText('metricIncomingVehicles', stats.incomingVehiclesTotal || 8);
  setText('metricOutgoingVehicles', stats.outgoingVehiclesTotal || 1);
  setText('metricCurrentlyParked', stats.currentlyParkedVehicles || 7);
  setText('metricAvailableSlots', `${available} / ${total}`);

  // Update Executive Home Master Dashboard stats
  setText('homeStatAvailable', `${available} / ${total}`);
  setText('homeStatOccupied', `${occupied} / ${total}`);
  setText('homeStatIncoming', stats.incomingVehiclesTotal || 8);
  setText('homeStatOutgoing', stats.outgoingVehiclesTotal || 1);

  // 🔒 RESTRICT PAYMENT & REVENUE VISIBILITY: ADMIN ONLY
  const revEl = document.getElementById('metricTotalRevenue');
  const revSub = document.getElementById('metricRevenueSub');
  if (state.adminLoggedIn) {
    if (revEl) revEl.innerText = `₹${(stats.todayRevenue || 200).toFixed(2)}`;
    if (revSub) revSub.innerHTML = `<span style="color:#10b981; font-weight: 600;">● Unlocked (Admin View)</span>`;
  } else {
    if (revEl) revEl.innerText = `🔒 Admin Only`;
    if (revSub) revSub.innerHTML = `<span style="color:#00f2fe; text-decoration: underline;">Click to Login as Admin</span>`;
  }

  // Update navbar role badge
  const roleBadge = document.getElementById('roleBadge');
  if (roleBadge) {
    if (state.adminLoggedIn) {
      roleBadge.className = 'nav-role-badge admin';
      roleBadge.innerHTML = `🛡️ Admin: ${state.adminEmail || 'admin@smartparking.com'}`;
    } else {
      roleBadge.className = 'nav-role-badge';
      roleBadge.innerHTML = `Visitor Mode (Public)`;
    }
  }
}

// Update 4-floor glance monitor cards on Home Master Dashboard
function updateFloorMonitors(slots) {
  for (let floor = 0; floor <= 3; floor++) {
    const fSlots = slots.filter(s => s.floorLevel === floor);
    const total = fSlots.length || 10;
    const occ = fSlots.filter(s => s.status === 'OCCUPIED').length;
    const avail = total - occ;
    const pct = Math.round((occ / total) * 100);

    const txtEl = document.getElementById(`floor${floor}OccupancyText`);
    const barEl = document.getElementById(`floor${floor}Progress`);
    const badgeEl = document.getElementById(`floor${floor}Badge`);

    if (txtEl) {
      txtEl.innerHTML = `<strong style="color: #fff;">${occ}/${total}</strong> occupied &bull; <span style="color:#10b981;">${avail} free</span> (${pct}%)`;
    }
    if (barEl) {
      barEl.style.width = `${pct}%`;
      barEl.style.backgroundColor = pct >= 80 ? '#ef4444' : (pct >= 40 ? '#f59e0b' : '#10b981');
    }
    if (badgeEl) {
      badgeEl.style.background = pct >= 80 ? 'rgba(239,68,68,0.2)' : 'rgba(16,185,129,0.2)';
      badgeEl.style.color = pct >= 80 ? '#f87171' : '#34d399';
      badgeEl.innerText = pct >= 80 ? 'Nearly Full' : `${avail} Ready`;
    }
  }
}

function jumpToFloor(level) {
  state.currentFloor = parseInt(level);
  document.querySelectorAll('.floor-btn').forEach((b, idx) => {
    b.classList.toggle('active', idx === level);
  });
  renderSlotsGrid();
  navigateTo('slots');
}

function switchFloor(floorNum, btn) {
  state.currentFloor = parseInt(floorNum);
  document.querySelectorAll('.floor-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderSlotsGrid();
}

// =====================================================================
// CLEAN ENTERPRISE PARKING BAY DISPLAY (NO BULKY CARTOON IMAGES)
// =====================================================================
function getVehicleSeatSvg(slotType, status, vehicleNumber) {
  const isOcc = status === 'OCCUPIED';
  const isRes = status === 'RESERVED';
  const isAvail = status === 'AVAILABLE';

  let typeIcon = '🚗';
  let typeLabel = '4-Wheeler Bay';
  if (slotType === 'TWO_WHEELER') {
    typeIcon = '🏍️';
    typeLabel = '2-Wheeler Stall';
  } else if (slotType === 'EV') {
    typeIcon = '⚡';
    typeLabel = 'EV Charging Stall';
  } else if (slotType === 'HEAVY_VEHICLE') {
    typeIcon = '🚛';
    typeLabel = 'Heavy Vehicle Bay';
  }

  const badgeClass = isOcc ? 'occupied' : (isRes ? 'reserved' : 'available');

  let centerBadge = '';
  if (isOcc) {
    centerBadge = `
      <div class="stall-license-plate">
        <span class="plate-country">IND</span>
        <span class="plate-number">${vehicleNumber || 'OCCUPIED'}</span>
      </div>
      <div class="stall-live-status occupied">● VEHICLE PARKED</div>
    `;
  } else if (isRes) {
    centerBadge = `
      <div class="stall-badge-reserved">VIP RESERVED</div>
      <div class="stall-live-status reserved">● HELD FOR MEMBER</div>
    `;
  } else {
    centerBadge = `
      <div class="stall-badge-available">OPEN BAY</div>
      <div class="stall-live-status available">● SENSOR READY</div>
    `;
  }

  return `
    <div class="clean-stall-card ${badgeClass}">
      <div class="clean-stall-head">
        <span>${typeIcon} ${typeLabel}</span>
      </div>
      <div class="clean-stall-body">
        ${centerBadge}
      </div>
    </div>
  `;
}

// =====================================================================
// 4-FLOOR PARKING GRID (GREEN = AVAILABLE, RED = OCCUPIED, YELLOW = RESERVED)
// =====================================================================
function renderSlotsGrid() {
  const container = document.getElementById('slotsGridContainer');
  if (!container) return;

  const floorSlots = state.slots.filter(s => s.floorLevel === state.currentFloor);
  container.innerHTML = '';

  if (floorSlots.length === 0) {
    container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 2rem;">No slots found on this floor.</div>`;
    return;
  }

  floorSlots.forEach(slot => {
    const isAvail = slot.status === 'AVAILABLE';
    const isOcc = slot.status === 'OCCUPIED';
    const isRes = slot.status === 'RESERVED';

    const card = document.createElement('div');
    card.className = `slot-card status-${slot.status.toLowerCase()}`;

    let statusText = isAvail ? 'Available' : (isOcc ? 'Occupied' : 'Reserved');

    card.innerHTML = `
      <div class="slot-header">
        <span class="slot-code">${slot.slotNumber}</span>
        <span class="status-tag">${statusText}</span>
      </div>

      <!-- VISUAL SEAT / PARKING BAY ILLUSTRATION -->
      ${getVehicleSeatSvg(slot.slotType, slot.status, slot.vehicleNumber)}

      <div style="margin-bottom: 0.85rem;">
        <div class="slot-detail-row">
          <span>Category:</span>
          <strong>${formatVehicleType(slot.slotType)}</strong>
        </div>
        <div class="slot-detail-row">
          <span>Distance to Gate:</span>
          <strong>${slot.distanceScore}m</strong>
        </div>
        <div class="slot-detail-row">
          <span>Tariff Rate:</span>
          <strong style="color: #00f2fe;">₹${slot.baseHourlyRate || 50}/hr</strong>
        </div>
        ${slot.hasEvCharger ? `
          <div class="slot-detail-row" style="color: #06b6d4;">
            <span>Charger:</span>
            <strong>⚡ Level 2 Fast</strong>
          </div>
        ` : ''}
      </div>

      <div>
        ${isAvail 
          ? `<button class="btn-slot-action btn-book-action" onclick="bookSpecificSlot('${slot.slotNumber}')">Book Bay</button>`
          : (isOcc 
              ? `<button class="btn-slot-action btn-exit-action" onclick="lookupVehicleForPayment('${slot.vehicleNumber || slot.slotNumber}')">Exit & Pay</button>`
              : `<button class="btn-slot-action" style="background: rgba(255,255,255,0.08); color: var(--text-dim);" disabled>Reserved</button>`
            )
        }
      </div>
    `;

    container.appendChild(card);
  });
}

async function updateNearestSlotRecommendation() {
  const display = document.getElementById('nearestSlotDisplay');
  const homeBadge = document.getElementById('homeNearestSlotBadge');

  const candidate = await ApiClient.getNearestSlot(state.selectedVehicleType);
  if (candidate) {
    if (display) display.innerText = `${candidate.slotNumber} (Floor ${candidate.floorLevel})`;
    if (homeBadge) homeBadge.innerText = `${candidate.slotNumber} (Floor ${candidate.floorLevel} • ${candidate.distanceScore}m)`;
    setText('previewSlotNumber', candidate.slotNumber);
    setText('previewFloor', `Floor ${candidate.floorLevel} &bull; ${candidate.distanceScore}m from Gate`);
  } else {
    if (display) display.innerText = 'FULL';
    if (homeBadge) homeBadge.innerText = 'FULL (All Floors)';
    setText('previewSlotNumber', 'N/A');
    setText('previewFloor', 'All 4 floors occupied');
  }
}

function quickBookNearest() {
  navigateTo('book');
  const modeSelect = document.getElementById('bookAllocationMode');
  if (modeSelect) modeSelect.value = 'AUTO';
  toggleManualSlotPicker();
}

function bookSpecificSlot(slotNum) {
  navigateTo('book');
  const modeSelect = document.getElementById('bookAllocationMode');
  if (modeSelect) modeSelect.value = 'MANUAL';
  toggleManualSlotPicker();
  const slotDropdown = document.getElementById('bookManualSlot');
  if (slotDropdown) slotDropdown.value = slotNum;
  updateTicketPreview();
}

// =====================================================================
// VEHICLE BOOKING
// =====================================================================
function selectVehicleType(type, el) {
  state.selectedVehicleType = type;
  document.querySelectorAll('.type-card-btn').forEach(b => b.classList.remove('selected'));
  if (el) el.classList.add('selected');

  populateManualSlotDropdown();
  updateNearestSlotRecommendation();
  updateTicketPreview();
}

function toggleManualSlotPicker() {
  const mode = document.getElementById('bookAllocationMode').value;
  const manualGroup = document.getElementById('manualSlotGroup');
  manualGroup.style.display = (mode === 'MANUAL') ? 'block' : 'none';
  if (mode === 'MANUAL') {
    populateManualSlotDropdown();
  }
  updateTicketPreview();
}

function populateManualSlotDropdown() {
  const dropdown = document.getElementById('bookManualSlot');
  if (!dropdown) return;

  const availableSlots = state.slots.filter(s => s.status === 'AVAILABLE');
  dropdown.innerHTML = availableSlots.length === 0 
    ? '<option value="">No slots available</option>'
    : availableSlots.map(s => `
        <option value="${s.slotNumber}">${s.slotNumber} (Floor ${s.floorLevel} - ${s.distanceScore}m away - ₹${s.baseHourlyRate}/hr)</option>
      `).join('');
}

function updateTicketPreview() {
  const reg = document.getElementById('bookVehicleNumber')?.value || 'KA-01-MJ-2024';
  const owner = document.getElementById('bookOwnerName')?.value || 'Rahul Sharma';
  const mode = document.getElementById('bookAllocationMode')?.value;
  const manualSlot = document.getElementById('bookManualSlot')?.value;

  setText('previewVehicle', reg.toUpperCase());
  setText('previewOwner', owner);
  setText('previewType', formatVehicleType(state.selectedVehicleType));
  setText('previewTime', new Date().toLocaleTimeString());

  const rate = defaultTariffs[state.selectedVehicleType] || 50.0;
  setText('previewRate', `₹${rate}.00 / hr`);

  if (mode === 'MANUAL' && manualSlot) {
    const slot = state.slots.find(s => s.slotNumber === manualSlot);
    setText('previewSlotNumber', manualSlot);
    if (slot) setText('previewFloor', `Floor ${slot.floorLevel} &bull; ${slot.distanceScore}m from Gate`);
  }
}

async function handleBookingSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('btnSubmitBooking');
  btn.disabled = true;
  btn.innerText = 'Allocating Slot...';

  try {
    const vehicleNumber = document.getElementById('bookVehicleNumber').value.trim();
    const ownerName = document.getElementById('bookOwnerName').value.trim();
    const contactNumber = document.getElementById('bookContact').value.trim();
    const mode = document.getElementById('bookAllocationMode').value;
    const preferredSlotNumber = (mode === 'MANUAL') ? document.getElementById('bookManualSlot').value : null;

    const payload = {
      vehicleNumber,
      ownerName,
      contactNumber,
      vehicleType: state.selectedVehicleType,
      preferredSlotNumber
    };

    const res = await ApiClient.createBooking(payload);

    await refreshAllData();

    showReceiptModal({
      receiptNumber: res.bookingCode,
      vehicleNumber: res.vehicleNumber,
      ownerName: res.ownerName,
      slotNumber: res.slotNumber,
      entryTime: new Date(res.entryTime).toLocaleString(),
      exitTime: 'ACTIVE PARKING IN PROGRESS',
      durationFormatted: 'Just Entered',
      paymentMethod: 'PAY AT EXIT',
      amount: res.hourlyRate // shows 1 hour base rate on pass
    });

    showToast(`Slot ${res.slotNumber} allocated! Barrier gate open.`, 'success');

    document.getElementById('bookingForm').reset();
    selectVehicleType('FOUR_WHEELER', document.querySelector('.type-card-btn'));
  } catch (err) {
    showToast(err.message || 'Booking failed', 'error');
  } finally {
    btn.disabled = false;
    btn.innerText = 'Confirm Booking & Generate Pass';
  }
}

// =====================================================================
// PAYMENT & EXIT (ACCURATE HOURLY CALCULATION - NEVER 0.00)
// =====================================================================
async function loadQuickCarChips() {
  const container = document.getElementById('quickChipsContainer');
  if (!container) return;

  const occupiedSlots = state.slots.filter(s => s.status === 'OCCUPIED' && s.vehicleNumber);

  if (occupiedSlots.length === 0) {
    container.innerHTML = `<span style="font-size: 0.8rem; color: var(--text-dim);">No active parked vehicles</span>`;
    return;
  }

  container.innerHTML = occupiedSlots.map(s => `
    <span class="quick-chip" onclick="quickFillPayment('${s.vehicleNumber}')">
      ${s.vehicleNumber} (${s.slotNumber})
    </span>
  `).join('');
}

function quickFillPayment(reg) {
  const input = document.getElementById('payLookupInput');
  if (input) input.value = reg;
  lookupVehicleForPayment(reg);
}

async function lookupVehicleForPayment(optionalQuery) {
  const query = optionalQuery || document.getElementById('payLookupInput')?.value;
  if (!query) {
    showToast('Please enter a vehicle license plate number', 'error');
    return;
  }

  try {
    const bill = await ApiClient.calculateExitBill(
      query,
      state.activePlanType,
      state.activePlanValue,
      state.simulatedMinutes
    );
    state.currentBill = bill;
    displayBillDetails(bill);

    showToast(`Bill calculated for ${bill.vehicleNumber}: ₹${Number(bill.totalAmount).toFixed(2)}`, 'info');
    document.getElementById('paymentDetailsSection').scrollIntoView({ behavior: 'smooth' });
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function displayBillDetails(bill) {
  document.getElementById('paymentDetailsSection').style.display = 'grid';

  setText('billBookingCode', bill.bookingCode);
  setText('billVehicleNumber', bill.vehicleNumber);
  setText('billSlotNumber', `${bill.slotNumber} (Floor ${bill.floorLevel})`);
  setText('billSlotTag', bill.slotNumber);
  setText('billEntryTime', new Date(bill.entryTime).toLocaleString());
  setText('billExitTime', new Date(bill.exitTime).toLocaleString());
  setText('billDuration', bill.durationFormatted);
  setText('billHourlyRate', bill.appliedRateLabel || `₹${bill.hourlyRate}.00 / hr`);
  setText('billTotalAmount', `₹${Number(bill.totalAmount).toFixed(2)}`);

  setText('cardHolderText', (bill.ownerName || 'DRIVER').toUpperCase());
}

function switchPlanCategory(category, btn) {
  document.querySelectorAll('.plan-tab-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  const containers = {
    hourly: 'planContainerHourly',
    daily: 'planContainerDaily',
    monthly: 'planContainerMonthly',
    yearly: 'planContainerYearly'
  };

  Object.keys(containers).forEach(key => {
    const el = document.getElementById(containers[key]);
    if (el) el.style.display = (key === category) ? 'flex' : 'none';
  });

  const typeMap = {
    hourly: 'hour',
    daily: 'day',
    monthly: 'month',
    yearly: 'year'
  };

  state.activePlanType = typeMap[category] || 'hour';
  state.activePlanValue = 1;

  // Highlight first pill in active container
  const activeContainer = document.getElementById(containers[category]);
  if (activeContainer) {
    const firstPill = activeContainer.querySelector('.plan-pill-btn');
    activeContainer.querySelectorAll('.plan-pill-btn').forEach(p => p.classList.remove('active'));
    if (firstPill) firstPill.classList.add('active');
  }

  // If hourly, sync the dropdown to 1
  if (state.activePlanType === 'hour') {
    const dd = document.getElementById('hourlySelectDropdown');
    if (dd) dd.value = '1';
  }

  recalculateBillForActivePlan();
}

function selectDurationOption(planType, value, btn) {
  state.activePlanType = planType;
  state.activePlanValue = parseInt(value) || 1;

  if (btn) {
    const parent = btn.parentElement;
    if (parent) {
      parent.querySelectorAll('.plan-pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    }
  }

  // If hourly, sync the dropdown
  if (planType === 'hour') {
    const dd = document.getElementById('hourlySelectDropdown');
    if (dd) dd.value = state.activePlanValue;
  }

  recalculateBillForActivePlan();
}

async function recalculateBillForActivePlan() {
  if (!state.currentBill) return;
  try {
    const bill = await ApiClient.calculateExitBill(
      state.currentBill.vehicleNumber,
      state.activePlanType,
      state.activePlanValue,
      state.simulatedMinutes
    );
    state.currentBill = bill;
    displayBillDetails(bill);
  } catch (err) {
    console.error('Recalculate error:', err);
  }
}

function simulateHours(hours, btn) {
  document.querySelectorAll('.hour-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  state.simulatedMinutes = hours * 60;
  if (state.currentBill) {
    recalculateBillForActivePlan();
  }
}

function selectPaymentMethod(method, el) {
  state.selectedPaymentMethod = method;
  document.querySelectorAll('.pay-method-card').forEach(b => b.classList.remove('active'));
  if (el) el.classList.add('active');

  ['UPI', 'CARD', 'CASH', 'RAZORPAY'].forEach(m => {
    const c = document.getElementById(`methodContainer${m.charAt(0) + m.slice(1).toLowerCase()}`);
    if (c) c.style.display = (m === method) ? 'block' : 'none';
  });
}

async function processFinalPayment() {
  if (!state.currentBill) {
    showToast('Please look up an active vehicle bill first', 'error');
    return;
  }

  try {
    const payload = {
      bookingCode: state.currentBill.bookingCode,
      paymentMethod: state.selectedPaymentMethod,
      amount: state.currentBill.totalAmount,
      notes: `Settled via ${state.selectedPaymentMethod} (${state.currentBill.durationFormatted})`
    };

    const res = await ApiClient.processPayment(payload);

    await refreshAllData();

    showReceiptModal({
      receiptNumber: res.receiptNumber,
      vehicleNumber: res.vehicleNumber,
      ownerName: res.ownerName,
      slotNumber: res.slotNumber,
      entryTime: new Date(res.entryTime).toLocaleString(),
      exitTime: new Date(res.exitTime).toLocaleString(),
      durationFormatted: res.durationFormatted,
      paymentMethod: res.paymentMethod,
      amount: res.amount
    });

    showToast(`Payment of ₹${Number(res.amount).toFixed(2)} received! Slot ${res.slotNumber} is now Green (Available).`, 'success');

    document.getElementById('paymentDetailsSection').style.display = 'none';
    state.currentBill = null;
    state.simulatedMinutes = null;
    document.getElementById('payLookupInput').value = '';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// =====================================================================
// ADMIN AUTHENTICATION & DASHBOARD (DEDICATED EMAIL & PASSWORD)
// =====================================================================
async function handleAdminLogin(e) {
  e.preventDefault();
  const email = (document.getElementById('adminEmail')?.value || '').trim();
  const password = (document.getElementById('adminPassword')?.value || '').trim();

  try {
    const res = await ApiClient.adminLogin({ email, password });
    state.adminLoggedIn = true;
    state.adminEmail = res.adminEmail || email;

    document.getElementById('adminLoginPanel').style.display = 'none';
    document.getElementById('adminConsole').style.display = 'block';
    setText('adminLoggedUserDisplay', state.adminEmail);

    showToast('Admin logged in! Financial metrics & control unlocked.', 'success');

    await loadAdminData();
    await refreshAllData();
  } catch (err) {
    showToast(err.message || 'Login failed', 'error');
  }
}

function handleAdminLogout() {
  state.adminLoggedIn = false;
  state.adminEmail = null;
  document.getElementById('adminLoginPanel').style.display = 'block';
  document.getElementById('adminConsole').style.display = 'none';
  showToast('Logged out of Admin Portal. Financial metrics locked.', 'info');
  refreshAllData();
}

async function loadAdminData() {
  const stats = await ApiClient.getAdminStats();

  // Populate 4 Financial Revenue Cards
  setText('adminStatGrossRevenue', `₹${Number(stats.todayRevenue || 0).toFixed(2)}`);
  setText('adminStatUpiRevenue', `₹${Number(stats.upiRevenue || 0).toFixed(2)}`);
  setText('adminStatCashRevenue', `₹${Number(stats.cashRevenue || 0).toFixed(2)}`);
  setText('adminStatCardRevenue', `₹${Number(stats.cardRevenue || 0).toFixed(2)}`);

  // Populate Bay Override Selector
  populateAdminOverrideSlotDropdown();

  // Populate Tariffs & Tables
  await populateAdminTariffInputs();
  renderAdminBookingsTable();
  renderAdminPaymentsTable();
}

function populateAdminOverrideSlotDropdown() {
  const select = document.getElementById('adminOverrideSlotSelect');
  if (!select) return;

  select.innerHTML = state.slots.map(s => `
    <option value="${s.slotNumber}">${s.slotNumber} (Floor ${s.floorLevel} - ${s.status})</option>
  `).join('');
}

async function toggleSlotMaintenanceAction() {
  const slotNum = document.getElementById('adminOverrideSlotSelect')?.value;
  if (!slotNum) return;

  try {
    const updated = await ApiClient.toggleSlotMaintenance(slotNum);
    showToast(`Slot ${slotNum} status toggled to: ${updated.status}`, 'info');
    await refreshAllData();
    populateAdminOverrideSlotDropdown();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function toggleSlotEvAction() {
  const slotNum = document.getElementById('adminOverrideSlotSelect')?.value;
  if (!slotNum) return;

  try {
    const updated = await ApiClient.toggleSlotEv(slotNum);
    showToast(`Slot ${slotNum} EV Charger: ${updated.hasEvCharger ? 'ENABLED' : 'DISABLED'}`, 'info');
    await refreshAllData();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function handleAdminPasswordUpdate(e) {
  e.preventDefault();
  const newPass = document.getElementById('newAdminPassword')?.value;
  if (!newPass || newPass.length < 4) {
    showToast('Password must be at least 4 characters long', 'error');
    return;
  }

  try {
    await ApiClient.updateAdminPassword(newPass);
    showToast('Admin password updated successfully!', 'success');
    document.getElementById('newAdminPassword').value = '';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Filter and Render Admin Sessions
function filterAdminSessions() {
  renderAdminBookingsTable();
}

function renderAdminBookingsTable() {
  const body = document.getElementById('adminBookingsTableBody');
  if (!body) return;

  const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
  const query = (document.getElementById('adminSessionSearchInput')?.value || '').trim().toLowerCase();
  const statusFilter = document.getElementById('adminSessionFilterStatus')?.value || 'ALL';

  const filtered = bookings.filter(b => {
    const matchQuery = !query || 
      b.bookingCode.toLowerCase().includes(query) || 
      b.vehicleNumber.toLowerCase().includes(query) ||
      b.slotNumber.toLowerCase().includes(query) ||
      (b.ownerName && b.ownerName.toLowerCase().includes(query));

    const matchStatus = (statusFilter === 'ALL') || (b.status === statusFilter);
    return matchQuery && matchStatus;
  });

  if (filtered.length === 0) {
    body.innerHTML = `<tr><td colspan="9" style="text-align: center; color: var(--text-dim); padding: 1.5rem;">No matching sessions found</td></tr>`;
    return;
  }

  body.innerHTML = filtered.map(b => {
    const entryFormatted = b.entryTime ? new Date(b.entryTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--';
    const exitFormatted = b.exitTime ? new Date(b.exitTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--';

    const now = Date.now();
    const entryDate = b.entryTime ? new Date(b.entryTime) : new Date(now);
    const elapsedMinutes = Math.max(1, Math.round((now - entryDate.getTime()) / 60000));
    const h = Math.floor(elapsedMinutes / 60);
    const m = elapsedMinutes % 60;
    const durStr = b.durationMinutes ? `${Math.floor(b.durationMinutes/60)}h ${b.durationMinutes%60}m` : (h > 0 ? `${h}h ${m}m` : `${m} mins`);

    const isAct = b.status === 'ACTIVE';

    return `
      <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
        <td style="padding: 0.75rem;"><strong>${b.bookingCode}</strong></td>
        <td style="padding: 0.75rem; font-family: monospace; font-weight: 700;">${b.vehicleNumber}</td>
        <td style="padding: 0.75rem;">${b.slotNumber} (Floor ${b.floorLevel})</td>
        <td style="padding: 0.75rem;">${formatVehicleType(b.vehicleType)}</td>
        <td style="padding: 0.75rem; color: #00f2fe;">${entryFormatted}</td>
        <td style="padding: 0.75rem; color: #ec4899;">${exitFormatted}</td>
        <td style="padding: 0.75rem; color: #f59e0b;">${durStr}</td>
        <td style="padding: 0.75rem;">
          <span class="status-tag" style="${isAct ? 'background: rgba(239,68,68,0.2); color: #f87171;' : 'background: rgba(16,185,129,0.2); color: #34d399;'}">
            ${b.status}
          </span>
        </td>
        <td style="padding: 0.75rem; text-align: right;">
          ${isAct 
            ? `<button class="btn btn-sm btn-primary" onclick="quickFillPayment('${b.vehicleNumber}')" style="padding: 0.25rem 0.6rem; font-size: 0.75rem;">Exit & Pay</button>` 
            : `<button class="btn btn-sm btn-secondary" onclick="lookupVehicleForPayment('${b.vehicleNumber}')" style="padding: 0.25rem 0.6rem; font-size: 0.75rem;">Receipt</button>`}
        </td>
      </tr>
    `;
  }).join('');
}

function renderAdminPaymentsTable() {
  const body = document.getElementById('adminPaymentsTableBody');
  if (!body) return;

  const payments = JSON.parse(localStorage.getItem('SP_PAYMENTS_V4') || '[]');
  if (payments.length === 0) {
    body.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-dim); padding: 1.5rem;">No payment transactions recorded today</td></tr>`;
    return;
  }

  body.innerHTML = payments.map(p => `
    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
      <td style="padding: 0.75rem;"><strong>${p.receiptNumber}</strong></td>
      <td style="padding: 0.75rem;">${p.bookingCode}</td>
      <td style="padding: 0.75rem; color: #34d399; font-weight: 700;">₹${Number(p.amount).toFixed(2)}</td>
      <td style="padding: 0.75rem;">${p.paymentMethod}</td>
      <td style="padding: 0.75rem;"><span style="color: #34d399; font-weight: 700;">PAID</span></td>
      <td style="padding: 0.75rem;">${new Date(p.paymentTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
    </tr>
  `).join('');
}

function exportSessionsCsv() {
  const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
  if (bookings.length === 0) {
    showToast('No sessions to export', 'error');
    return;
  }

  let csv = 'BookingID,VehicleNumber,SlotNumber,FloorLevel,VehicleType,OwnerName,ContactNumber,EntryTime,ExitTime,DurationMinutes,Status\n';
  bookings.forEach(b => {
    csv += `"${b.bookingCode}","${b.vehicleNumber}","${b.slotNumber}","${b.floorLevel}","${b.vehicleType}","${b.ownerName || ''}","${b.contactNumber || ''}","${b.entryTime || ''}","${b.exitTime || ''}","${b.durationMinutes || ''}","${b.status}"\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `smart_parking_sessions_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast('Downloaded sessions CSV audit log!', 'success');
}

function printDailyLedger() {
  window.print();
}

// =====================================================================
// LIVE HOME PAGE TRAFFIC MOVEMENT TABLES (INCOMING & OUTGOING)
// =====================================================================
function switchHomeTrafficTab(tab) {
  const incBtn = document.getElementById('tabBtnIncoming');
  const outBtn = document.getElementById('tabBtnOutgoing');
  const incCon = document.getElementById('homeIncomingContainer');
  const outCon = document.getElementById('homeOutgoingContainer');

  if (tab === 'incoming') {
    if (incBtn) { incBtn.className = 'btn btn-sm btn-primary'; }
    if (outBtn) { outBtn.className = 'btn btn-sm btn-secondary'; }
    if (incCon) incCon.style.display = 'block';
    if (outCon) outCon.style.display = 'none';
  } else {
    if (incBtn) { incBtn.className = 'btn btn-sm btn-secondary'; }
    if (outBtn) { outBtn.className = 'btn btn-sm btn-primary'; }
    if (incCon) incCon.style.display = 'none';
    if (outCon) outCon.style.display = 'block';
  }
}

function scrollToTrafficFeed(tab) {
  navigateTo('home');
  switchHomeTrafficTab(tab);
  const el = document.getElementById('homeTrafficSection');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function renderHomeTrafficTables() {
  const incBody = document.getElementById('homeIncomingTableBody');
  const outBody = document.getElementById('homeOutgoingTableBody');
  const incCountEl = document.getElementById('homeIncomingCount');
  const outCountEl = document.getElementById('homeOutgoingCount');

  const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
  const activeList = bookings.filter(b => b.status === 'ACTIVE');
  const completedList = bookings.filter(b => b.status === 'COMPLETED');

  if (incCountEl) incCountEl.innerText = activeList.length;
  if (outCountEl) outCountEl.innerText = completedList.length;

  // Render Incoming (Active inside)
  if (incBody) {
    if (activeList.length === 0) {
      incBody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim); padding: 1.5rem;">No active vehicles inside. All bays are available!</td></tr>`;
    } else {
      const now = Date.now();
      incBody.innerHTML = activeList.map(b => {
        const entryDate = b.entryTime ? new Date(b.entryTime) : new Date(now);
        const elapsedMinutes = Math.max(1, Math.round((now - entryDate.getTime()) / 60000));
        const h = Math.floor(elapsedMinutes / 60);
        const m = elapsedMinutes % 60;
        const durStr = h > 0 ? `${h}h ${m}m` : `${m} mins`;

        const formattedEntry = entryDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        return `
          <tr class="traffic-table-row">
            <td style="padding: 0.75rem;"><strong style="color: #00f2fe;">${b.slotNumber}</strong> (Floor ${b.floorLevel})</td>
            <td style="padding: 0.75rem; font-family: monospace; font-weight: 700; color: #fff;">${b.vehicleNumber}</td>
            <td style="padding: 0.75rem;">${formatVehicleType(b.vehicleType)}</td>
            <td style="padding: 0.75rem; color: #00f2fe;">${formattedEntry}</td>
            <td style="padding: 0.75rem; color: #f59e0b; font-weight: 600;">${durStr}</td>
            <td style="padding: 0.75rem; color: var(--text-muted);">${b.ownerName || 'Driver'} • ${b.contactNumber || '--'}</td>
            <td style="padding: 0.75rem; text-align: right;">
              <button class="btn btn-sm btn-primary" onclick="quickFillPayment('${b.vehicleNumber}')" style="padding: 0.3rem 0.75rem; font-size: 0.78rem;">
                Exit & Pay
              </button>
            </td>
          </tr>
        `;
      }).join('');
    }
  }

  // Render Outgoing (Departed & Cleared)
  if (outBody) {
    if (completedList.length === 0) {
      outBody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-dim); padding: 1.5rem;">No vehicles checked out yet today.</td></tr>`;
    } else {
      outBody.innerHTML = completedList.map(b => {
        const entryFormatted = b.entryTime ? new Date(b.entryTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--';
        const exitFormatted = b.exitTime ? new Date(b.exitTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--';
        const durStr = b.durationMinutes ? `${Math.floor(b.durationMinutes/60)}h ${b.durationMinutes%60}m` : 'Completed';

        // 🔒 Financial amount masked unless Admin
        const payDisplay = state.adminLoggedIn 
          ? `<strong style="color: #34d399;">₹${Number(b.amount || 200).toFixed(2)}</strong>`
          : `<span class="status-tag" style="background: rgba(16,185,129,0.2); color: #34d399;">PAID & CLEARED</span>`;

        return `
          <tr class="traffic-table-row">
            <td style="padding: 0.75rem;"><strong>${b.bookingCode}</strong></td>
            <td style="padding: 0.75rem; font-family: monospace; font-weight: 700; color: #fff;">${b.vehicleNumber}</td>
            <td style="padding: 0.75rem;">${b.slotNumber}</td>
            <td style="padding: 0.75rem; color: #00f2fe;">${entryFormatted}</td>
            <td style="padding: 0.75rem; color: #ec4899;">${exitFormatted}</td>
            <td style="padding: 0.75rem; color: #f59e0b;">${durStr}</td>
            <td style="padding: 0.75rem;">${payDisplay}</td>
            <td style="padding: 0.75rem; text-align: right;">
              <button class="btn btn-sm btn-secondary" onclick="lookupVehicleForPayment('${b.vehicleNumber}')" style="padding: 0.25rem 0.6rem; font-size: 0.75rem;">
                Receipt
              </button>
            </td>
          </tr>
        `;
      }).join('');
    }
  }
}

// =====================================================================
// SHARE PUBLIC & LAN LINK MODAL
// =====================================================================
function openShareModal() {
  const modal = document.getElementById('shareModal');
  if (modal) modal.classList.add('active');
}

function closeShareModal() {
  const modal = document.getElementById('shareModal');
  if (modal) modal.classList.remove('active');
}

function copyLanLink() {
  const input = document.getElementById('shareLanUrlInput');
  if (input) {
    navigator.clipboard.writeText(input.value).then(() => {
      showToast('Copied Wi-Fi LAN link to clipboard: ' + input.value, 'success');
    }).catch(() => {
      input.select();
      document.execCommand('copy');
      showToast('Copied: ' + input.value, 'success');
    });
  }
}

async function populateAdminTariffInputs() {
  const tariffs = await ApiClient.getTariffs();

  setVal('rateFourWheelerHour', tariffs.RATE_FOUR_WHEELER_HOUR);
  setVal('rateFourWheelerDay', tariffs.RATE_FOUR_WHEELER_DAY);
  setVal('rateFourWheelerMonth', tariffs.RATE_FOUR_WHEELER_MONTH);
  setVal('rateFourWheelerYear', tariffs.RATE_FOUR_WHEELER_YEAR);

  setVal('rateTwoWheelerHour', tariffs.RATE_TWO_WHEELER_HOUR);
  setVal('rateTwoWheelerDay', tariffs.RATE_TWO_WHEELER_DAY);
  setVal('rateTwoWheelerMonth', tariffs.RATE_TWO_WHEELER_MONTH);
  setVal('rateTwoWheelerYear', tariffs.RATE_TWO_WHEELER_YEAR);

  setVal('rateEvHour', tariffs.RATE_EV_HOUR);
  setVal('rateEvDay', tariffs.RATE_EV_DAY);
  setVal('rateEvMonth', tariffs.RATE_EV_MONTH);
  setVal('rateEvYear', tariffs.RATE_EV_YEAR);

  setVal('rateHeavyHour', tariffs.RATE_HEAVY_VEHICLE_HOUR);
  setVal('rateHeavyDay', tariffs.RATE_HEAVY_VEHICLE_DAY);
  setVal('rateHeavyMonth', tariffs.RATE_HEAVY_VEHICLE_MONTH);
  setVal('rateHeavyYear', tariffs.RATE_HEAVY_VEHICLE_YEAR);
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el && val !== undefined) el.value = val;
}

async function updateBookingVehicleRates() {
  try {
    const tariffs = await ApiClient.getTariffs();
    setText('bookRateCar', `₹${tariffs.RATE_FOUR_WHEELER_HOUR}/hr • ₹${tariffs.RATE_FOUR_WHEELER_DAY}/day`);
    setText('bookRateBike', `₹${tariffs.RATE_TWO_WHEELER_HOUR}/hr • ₹${tariffs.RATE_TWO_WHEELER_DAY}/day`);
    setText('bookRateEv', `₹${tariffs.RATE_EV_HOUR}/hr • ₹${tariffs.RATE_EV_DAY}/day`);
    setText('bookRateHeavy', `₹${tariffs.RATE_HEAVY_VEHICLE_HOUR}/hr • ₹${tariffs.RATE_HEAVY_VEHICLE_DAY}/day`);
  } catch (e) {
    console.error('Failed to update booking rates', e);
  }
}

async function handleTariffUpdate(e) {
  e.preventDefault();

  const rates = {
    fourWheelerHour: parseFloat(document.getElementById('rateFourWheelerHour')?.value || 50),
    fourWheelerDay: parseFloat(document.getElementById('rateFourWheelerDay')?.value || 400),
    fourWheelerMonth: parseFloat(document.getElementById('rateFourWheelerMonth')?.value || 3500),
    fourWheelerYear: parseFloat(document.getElementById('rateFourWheelerYear')?.value || 32000),

    twoWheelerHour: parseFloat(document.getElementById('rateTwoWheelerHour')?.value || 20),
    twoWheelerDay: parseFloat(document.getElementById('rateTwoWheelerDay')?.value || 150),
    twoWheelerMonth: parseFloat(document.getElementById('rateTwoWheelerMonth')?.value || 1200),
    twoWheelerYear: parseFloat(document.getElementById('rateTwoWheelerYear')?.value || 10000),

    evHour: parseFloat(document.getElementById('rateEvHour')?.value || 60),
    evDay: parseFloat(document.getElementById('rateEvDay')?.value || 500),
    evMonth: parseFloat(document.getElementById('rateEvMonth')?.value || 4500),
    evYear: parseFloat(document.getElementById('rateEvYear')?.value || 40000),

    heavyVehicleHour: parseFloat(document.getElementById('rateHeavyHour')?.value || 80),
    heavyVehicleDay: parseFloat(document.getElementById('rateHeavyDay')?.value || 700),
    heavyVehicleMonth: parseFloat(document.getElementById('rateHeavyMonth')?.value || 6000),
    heavyVehicleYear: parseFloat(document.getElementById('rateHeavyYear')?.value || 55000)
  };

  try {
    await ApiClient.updateTariffs(rates);
    showToast('All 16 vehicle tariffs (Hour, Day, Month, Year) updated successfully!', 'success');
    await refreshAllData();
    await updateBookingVehicleRates();
    if (state.currentBill) {
      recalculateBillForActivePlan();
    }
  } catch (err) {
    showToast(err.message || 'Failed to update tariffs', 'error');
  }
}

function renderAdminBookingsTable() {
  const body = document.getElementById('adminBookingsTableBody');
  if (!body) return;

  const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
  body.innerHTML = bookings.map(b => `
    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
      <td style="padding: 0.75rem;"><strong>${b.bookingCode}</strong></td>
      <td style="padding: 0.75rem;">${b.vehicleNumber}</td>
      <td style="padding: 0.75rem;">${b.slotNumber} (Floor ${b.floorLevel})</td>
      <td style="padding: 0.75rem;">${formatVehicleType(b.vehicleType)}</td>
      <td style="padding: 0.75rem;">${new Date(b.entryTime).toLocaleTimeString()}</td>
      <td style="padding: 0.75rem;">
        <span class="status-tag" style="${b.status === 'ACTIVE' ? 'background: rgba(239,68,68,0.2); color: #f87171;' : 'background: rgba(16,185,129,0.2); color: #34d399;'}">
          ${b.status}
        </span>
      </td>
    </tr>
  `).join('');
}

function renderAdminPaymentsTable() {
  const body = document.getElementById('adminPaymentsTableBody');
  if (!body) return;

  const payments = JSON.parse(localStorage.getItem('SP_PAYMENTS_V4') || '[]');
  body.innerHTML = payments.map(p => `
    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
      <td style="padding: 0.75rem;"><strong>${p.receiptNumber}</strong></td>
      <td style="padding: 0.75rem;">${p.bookingCode}</td>
      <td style="padding: 0.75rem;"><strong>₹${Number(p.amount).toFixed(2)}</strong></td>
      <td style="padding: 0.75rem;">${p.paymentMethod}</td>
      <td style="padding: 0.75rem;"><span style="color: #34d399; font-weight: 700;">PAID</span></td>
      <td style="padding: 0.75rem;">${new Date(p.paymentTime).toLocaleTimeString()}</td>
    </tr>
  `).join('');
}

// =====================================================================
// RECEIPT MODAL
// =====================================================================
function showReceiptModal(data) {
  setText('recReceiptNumber', data.receiptNumber);
  setText('recVehicleNumber', data.vehicleNumber);
  setText('recOwnerName', data.ownerName);
  setText('recSlotNumber', data.slotNumber);
  setText('recEntryTime', data.entryTime);
  setText('recExitTime', data.exitTime);
  setText('recDuration', data.durationFormatted);
  setText('recMethod', data.paymentMethod);
  setText('recAmount', `₹${Number(data.amount).toFixed(2)}`);

  document.getElementById('receiptModal').classList.add('active');
}

function closeReceiptModal() {
  document.getElementById('receiptModal').classList.remove('active');
}

// =====================================================================
// HELPERS
// =====================================================================
function formatVehicleType(type) {
  switch (type) {
    case 'FOUR_WHEELER': return '4-Wheeler Car';
    case 'TWO_WHEELER': return '2-Wheeler Bike';
    case 'EV': return 'Electric Vehicle (EV)';
    case 'HEAVY_VEHICLE': return 'Heavy / SUV';
    default: return type;
  }
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.innerText = text;
}

function showToast(msg, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerText = msg;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// =====================================================================
// PWA (PROGRESSIVE WEB APP) INSTALLATION & APP MODE
// =====================================================================
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const btn = document.getElementById('btnInstallApp');
  if (btn) btn.style.display = 'inline-flex';
});

function installPwaApp() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choice) => {
      if (choice.outcome === 'accepted') {
        showToast('Smart Parking App installed successfully! 🎉', 'success');
      }
      deferredPrompt = null;
    });
  } else {
    showToast('App is ready! On Android Chrome or Desktop, click browser menu ⋮ > "Install App" or "Add to Home screen". Or double-click SmartParkingApp.bat for Desktop App Mode.', 'info');
  }
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(err => {
      console.log('ServiceWorker note:', err);
    });
  });
}
