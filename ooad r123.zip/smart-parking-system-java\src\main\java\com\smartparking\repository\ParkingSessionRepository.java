package com.smartparking.repository;

import com.smartparking.entity.ParkingSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ParkingSessionRepository extends JpaRepository<ParkingSession, Long> {
    Optional<ParkingSession> findByTicketNumber(String ticketNumber);
    Optional<ParkingSession> findByVehicleNumberAndStatus(String vehicleNumber, String status);
    Optional<ParkingSession> findBySlotNumberAndStatus(String slotNumber, String status);
    List<ParkingSession> findByStatus(String status);
    long countByStatus(String status);
}
