package com.smartparking.repository;

import com.smartparking.entity.Subscription;
import com.smartparking.enums.VehicleCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    Optional<Subscription> findByPassNumber(String passNumber);
    Optional<Subscription> findByVehicleNumberAndCategoryAndStatusAndEndDateAfter(
        String vehicleNumber, VehicleCategory category, String status, LocalDateTime now
    );
    List<Subscription> findByStatus(String status);
}
