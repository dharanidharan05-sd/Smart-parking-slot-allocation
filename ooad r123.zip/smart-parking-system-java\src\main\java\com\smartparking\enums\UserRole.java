package com.smartparking.enums;

public enum UserRole {
    SUPER_ADMIN,
    PARKING_MANAGER,
    PARKING_STAFF,
    ACCOUNTANT,
    CUSTOMER
}
