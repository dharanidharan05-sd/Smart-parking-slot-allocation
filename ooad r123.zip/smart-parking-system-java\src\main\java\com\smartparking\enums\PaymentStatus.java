package com.smartparking.enums;

public enum PaymentStatus {
    PAID,
    PENDING,
    FAILED,
    REFUNDED
}
