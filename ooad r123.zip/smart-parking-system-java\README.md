# 🚗 Smart Parking Slot Allocation and Management System (100% Pure Java Spring Boot)

A full-stack, enterprise-grade Smart Parking Slot Allocation & Management System built entirely with **Java 8+, Spring Boot 2.7.18, Spring Data JPA, and H2/MySQL**.

---

## 🌟 Highlights
- **100% Full-Stack Java**: No Node.js / npm runtime needed. Everything runs inside a single Spring Boot application with an embedded responsive web UI at `http://localhost:8080`.
- **4 Vehicle Categories**: Two-Wheeler (B01–B10), Four-Wheeler (C01–C20), Commercial (CM01–CM10), Heavy Vehicle (HV01–HV05).
- **Interactive Visual Parking Grid**: Real-time status (Green=Available, Red=Occupied, Yellow=Reserved, Blue=Maintenance, Grey=Disabled).
- **Flexible Pricing Engine**: Hourly, Daily, Monthly, and Yearly billing plans with grace periods, ceiling rounding, overtime penalty, and 18% GST calculation.
- **Entry & Exit Workflow**: Real QR Code generation (ZXing), check-in, check-out fee calculation, receipt generation, and atomic slot release.
- **Monthly / Yearly Subscriptions**: Dedicated bay reservations with auto-expiry tracking.
- **Multi-Role Access**: Super Admin, Parking Manager, Parking Staff, Accountant, Customer.
- **Financial & Expense Management**: Operating expenses, net operating profit (`Gross Revenue - Expenses`), and audit logging.

---

## 🚀 How to Run in VS Code (VS Code la eppadi run pannanum)

### Method 1: Using Quick Batch Scripts (Easiest / 1-Click)
1. Unzip `smart-parking-system-java.zip`.
2. Open the folder `smart-parking-system-java`.
3. Double-click **`start-demo.bat`** (or **`run-backend.bat`**).
4. Spring Boot will start and automatically open **`http://localhost:8080`** in your browser!

### Method 2: Running Inside VS Code
1. Open VS Code.
2. Click **File -> Open Folder...** and select `smart-parking-system-java`.
3. Open `src/main/java/com/smartparking/SmartParkingApplication.java`.
4. Click **Run** or press **F5**.
5. Once the terminal shows `Started SmartParkingApplication`, open your browser and go to:
   👉 **http://localhost:8080**

### Method 3: Using Maven from Terminal / PowerShell
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```
Or with bundled VS Code Maven:
```cmd
run-backend.bat
```

---

## 🗄️ Database Access
- **Default Database**: In-memory H2 (Zero setup required!).
- **H2 Web Console**: `http://localhost:8080/h2-console`
  - JDBC URL: `jdbc:h2:mem:parkingdb`
  - Username: `sa`
  - Password: *(leave blank)*
- **MySQL Support**: To switch to MySQL, update `src/main/resources/application-mysql.properties` with your database credentials and run with `--spring.profiles.active=mysql`.

---

## 👥 Default Demo Credentials
| Role | Email | Password |
|---|---|---|
| **Super Admin** | `admin@smartparking.com` | `admin123` |
| **Parking Manager** | `manager@smartparking.com` | `manager123` |
| **Parking Staff** | `staff@smartparking.com` | `staff123` |
| **Accountant** | `accountant@smartparking.com` | `acc123` |
| **Customer** | `customer@smartparking.com` | `cust123` |
*(You can also switch roles with 1-click using the role switcher on the top navigation bar!)*
