package com.smartparking;

import com.smartparking.dto.ExitCalculationDTO;
import com.smartparking.entity.ParkingSession;
import com.smartparking.entity.ParkingSlot;
import com.smartparking.enums.BillingPlan;
import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.service.PricingEngineService;
import com.smartparking.service.SlotAllocationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SmartParkingApplicationTests {

    @Autowired
    private PricingEngineService pricingEngineService;

    @Autowired
    private SlotAllocationService slotAllocationService;

    @Test
    void test1_GracePeriodFreeCalculation() {
        ParkingSession session = new ParkingSession();
        session.setBillingPlan(BillingPlan.HOURLY);
        session.setEntryTime(LocalDateTime.now().minusMinutes(12)); // 12 minutes
        session.setSnapshotHourlyRate(BigDecimal.valueOf(30.0));
        session.setSnapshotGraceMinutes(15);
        session.setSnapshotTaxPercent(18.0);

        ExitCalculationDTO result = pricingEngineService.calculateFee(session, LocalDateTime.now(), 0.0);

        assertEquals(12L, result.getDurationMinutes());
        assertEquals(0, result.getBaseAmount().compareTo(BigDecimal.ZERO));
        assertEquals(0, result.getTotalAmount().compareTo(BigDecimal.ZERO));
    }

    @Test
    void test2_CeilHourlyRoundingPastGracePeriod() {
        ParkingSession session = new ParkingSession();
        session.setBillingPlan(BillingPlan.HOURLY);
        session.setEntryTime(LocalDateTime.now().minusMinutes(80)); // 1 hour 20 mins -> 2 hours billed
        session.setSnapshotHourlyRate(BigDecimal.valueOf(30.0));
        session.setSnapshotGraceMinutes(15);
        session.setSnapshotTaxPercent(18.0);

        ExitCalculationDTO result = pricingEngineService.calculateFee(session, LocalDateTime.now(), 0.0);

        assertEquals(80L, result.getDurationMinutes());
        assertEquals(0, result.getBaseAmount().compareTo(BigDecimal.valueOf(60.00))); // 2 * 30 = 60
        assertEquals(0, result.getTaxAmount().compareTo(BigDecimal.valueOf(10.80)));  // 18% of 60 = 10.8
        assertEquals(0, result.getTotalAmount().compareTo(BigDecimal.valueOf(70.80)));
    }

    @Test
    void test3_MultiDayDailyBlocks() {
        ParkingSession session = new ParkingSession();
        session.setBillingPlan(BillingPlan.DAILY);
        session.setEntryTime(LocalDateTime.now().minusHours(46)); // 46 hours -> 2 days billed
        session.setSnapshotDailyRate(BigDecimal.valueOf(180.0));
        session.setSnapshotGraceMinutes(15);
        session.setSnapshotTaxPercent(18.0);

        ExitCalculationDTO result = pricingEngineService.calculateFee(session, LocalDateTime.now(), 0.0);

        assertEquals(0, result.getBaseAmount().compareTo(BigDecimal.valueOf(360.00))); // 2 * 180 = 360
        assertEquals(0, result.getTaxAmount().compareTo(BigDecimal.valueOf(64.80)));
        assertEquals(0, result.getTotalAmount().compareTo(BigDecimal.valueOf(424.80)));
    }

    @Test
    void test4_PriceSnapshotImmutability() {
        // Session created with rate ₹30
        ParkingSession session = new ParkingSession();
        session.setBillingPlan(BillingPlan.HOURLY);
        session.setEntryTime(LocalDateTime.now().minusHours(2));
        session.setSnapshotHourlyRate(BigDecimal.valueOf(30.0)); // original rate
        session.setSnapshotTaxPercent(18.0);

        // Even if global tariff increases to ₹50, session must calculate using its snapshot rate (₹30)!
        ExitCalculationDTO result = pricingEngineService.calculateFee(session, LocalDateTime.now(), 0.0);

        assertEquals(0, result.getBaseAmount().compareTo(BigDecimal.valueOf(60.00)));
        assertNotEquals(0, result.getBaseAmount().compareTo(BigDecimal.valueOf(100.00)));
    }

    @Test
    void test5_SlotCompatibilityCheck() {
        ParkingSlot bikeSlot = new ParkingSlot();
        bikeSlot.setCategory(VehicleCategory.TWO_WHEELER);
        bikeSlot.setStatus(SlotStatus.AVAILABLE);
        bikeSlot.setLengthMeters(2.5);
        bikeSlot.setWidthMeters(1.2);

        // Compatible bike
        assertTrue(slotAllocationService.isCompatible(bikeSlot, VehicleCategory.TWO_WHEELER, 2.0, 1.0));

        // Incompatible heavy vehicle in bike bay
        assertFalse(slotAllocationService.isCompatible(bikeSlot, VehicleCategory.HEAVY, 12.0, 3.0));

        // Oversized bike
        assertFalse(slotAllocationService.isCompatible(bikeSlot, VehicleCategory.TWO_WHEELER, 3.5, 1.5));
    }
}
