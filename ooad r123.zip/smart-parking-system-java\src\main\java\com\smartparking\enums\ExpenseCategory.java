package com.smartparking.enums;

public enum ExpenseCategory {
    SALARY("Staff Salary"),
    ELECTRICITY("Electricity & Utilities"),
    MAINTENANCE("Facility Maintenance"),
    CLEANING("Cleaning & Janitorial"),
    EQUIPMENT("Hardware & Barriers"),
    REFUND("Customer Refunds"),
    OTHER("Other Operating Expenses");

    private final String label;

    ExpenseCategory(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
