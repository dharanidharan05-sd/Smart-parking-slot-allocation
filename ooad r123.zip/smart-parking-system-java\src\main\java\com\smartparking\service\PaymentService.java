package com.smartparking.service;

import com.smartparking.entity.Expense;
import com.smartparking.entity.Payment;
import com.smartparking.enums.ExpenseCategory;
import com.smartparking.enums.PaymentStatus;
import com.smartparking.repository.ExpenseRepository;
import com.smartparking.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private AuditService auditService;

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Transactional
    public Payment processRefund(Long id, String reason, String authorizedBy) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment record not found with ID: " + id));

        if (payment.getStatus() == PaymentStatus.REFUNDED) {
            throw new IllegalStateException("Transaction " + payment.getTransactionId() + " has already been refunded");
        }

        payment.setStatus(PaymentStatus.REFUNDED);
        payment.setRefundReason(reason);
        payment.setRefundDate(LocalDateTime.now());
        payment.setRefundAuthorizedBy(authorizedBy != null ? authorizedBy : "Accountant");
        Payment updated = paymentRepository.save(payment);

        // Record an Expense entry under REFUND category to maintain financial ledger accuracy!
        Expense refundExpense = new Expense(
                "Refund for Txn " + payment.getTransactionId(),
                ExpenseCategory.REFUND,
                payment.getTotalAmount(),
                "Authorized refund for vehicle " + payment.getVehicleNumber() + ". Reason: " + reason,
                payment.getPaymentMethod().name(),
                payment.getTransactionId()
        );
        expenseRepository.save(refundExpense);

        auditService.logEvent("PAYMENT_REFUNDED", "PAYMENT", payment.getTransactionId(), payment.getTotalAmount().toString(), "REFUNDED", reason);
        return updated;
    }
}
