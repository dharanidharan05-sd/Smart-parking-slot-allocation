package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.dto.DashboardMetricsDTO;
import com.smartparking.service.AuditService;
import com.smartparking.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private AuditService auditService;

    @GetMapping("/metrics")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getMetrics() {
        DashboardMetricsDTO metrics = dashboardService.getMetrics();
        Map<String, Object> data = new HashMap<>();
        data.put("metrics", metrics);
        data.put("recentActivities", auditService.getRecentLogs());
        return ResponseEntity.ok(ApiResponse.success(data));
    }
}
