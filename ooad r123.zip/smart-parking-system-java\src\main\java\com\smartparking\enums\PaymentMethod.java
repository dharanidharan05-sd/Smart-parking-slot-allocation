package com.smartparking.enums;

public enum PaymentMethod {
    CASH,
    UPI,
    CARD,
    ONLINE_GATEWAY
}
