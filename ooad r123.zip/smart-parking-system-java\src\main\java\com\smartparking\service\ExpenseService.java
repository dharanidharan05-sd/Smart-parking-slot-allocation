package com.smartparking.service;

import com.smartparking.entity.Expense;
import com.smartparking.repository.ExpenseRepository;
import com.smartparking.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private AuditService auditService;

    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll();
    }

    public Expense createExpense(Expense expense) {
        Expense saved = expenseRepository.save(expense);
        auditService.logEvent("EXPENSE_CREATED", "EXPENSE", saved.getTitle(), null, saved.getAmount().toString(), "Operational expense logged");
        return saved;
    }

    public void deleteExpense(Long id) {
        expenseRepository.deleteById(id);
        auditService.logEvent("EXPENSE_DELETED", "EXPENSE", id.toString(), null, null, "Expense record removed");
    }

    public Map<String, Object> getFinancialSummary() {
        BigDecimal grossRevenue = paymentRepository.sumTotalPaidRevenue();
        BigDecimal totalExpenses = expenseRepository.sumTotalExpenses();
        BigDecimal totalRefunds = paymentRepository.sumTotalRefundedAmount();
        BigDecimal netProfit = grossRevenue.subtract(totalExpenses);

        Map<String, Object> summary = new HashMap<>();
        summary.put("grossRevenue", grossRevenue);
        summary.put("totalExpenses", totalExpenses);
        summary.put("totalRefunds", totalRefunds);
        summary.put("netProfit", netProfit);
        return summary;
    }
}
