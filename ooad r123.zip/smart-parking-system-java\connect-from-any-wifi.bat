@echo off
title Smart Parking System - Connect From Any Wi-Fi / Worldwide
color 0b
echo ===============================================================================
echo        SMART PARKING SYSTEM - CONNECT FROM ANY DIFFERENT WI-FI
echo ===============================================================================
echo.
echo  This tool gives you a FREE, SECURE public HTTPS link that works on:
echo   * Different Wi-Fi networks (College Wi-Fi, Office Wi-Fi, Home Wi-Fi)
echo   * Mobile Data networks (Jio / Airtel / Vi 4G / 5G)
echo   * Any smartphone, laptop, or computer anywhere in the world!
echo.
echo ===============================================================================
echo.

REM Check if backend is responding on port 8080
echo Checking Spring Boot backend on http://localhost:8080 ...
curl -s -I http://localhost:8080 >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [NOTICE] Spring Boot backend is not running yet. Starting it now...
    start "Smart Parking Backend" cmd /c "run-backend.bat"
    echo Waiting 8 seconds for server to start...
    timeout /t 8 /nobreak >nul
)

echo.
echo ===============================================================================
echo  STARTING WORLDWIDE PUBLIC TUNNEL (NO SIGNUP REQUIRED)
echo ===============================================================================
echo.
echo  Generating your instant public HTTPS URL...
echo  (Keep this command window OPEN while you want people to access!)
echo.

REM Method 1: Pinggy SSH (zero setup, built into Windows OpenSSH)
if exist "%SystemRoot%\System32\OpenSSH\ssh.exe" (
    echo Using High-Speed Secure Public Tunnel via OpenSSH...
    echo.
    "%SystemRoot%\System32\OpenSSH\ssh.exe" -p 443 -R0:localhost:8080 -o StrictHostKeyChecking=no a.pinggy.io
    goto END
)

REM Method 2: Cloudflare via NPX
where npx >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo Using Cloudflare Quick Tunnel...
    npx -y cloudflared tunnel --url http://localhost:8080
    goto END
)

echo [ERROR] Neither OpenSSH nor Node.js NPX was found.
pause
:END
pause
