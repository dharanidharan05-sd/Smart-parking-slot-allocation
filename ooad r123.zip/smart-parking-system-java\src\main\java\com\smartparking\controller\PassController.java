package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.dto.PassPurchaseRequest;
import com.smartparking.entity.Subscription;
import com.smartparking.service.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/passes")
@CrossOrigin(origins = "*")
public class PassController {

    @Autowired
    private SubscriptionService subscriptionService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Subscription>>> getAllPasses() {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getAllPasses()));
    }

    @PostMapping("/purchase")
    public ResponseEntity<ApiResponse<Subscription>> purchasePass(@Valid @RequestBody PassPurchaseRequest request) {
        try {
            Subscription sub = subscriptionService.purchasePass(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Subscription pass issued successfully", sub));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PatchMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse<Subscription>> cancelPass(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        try {
            String reason = body.getOrDefault("reason", "Cancelled by customer/manager");
            Subscription cancelled = subscriptionService.cancelPass(id, reason);
            return ResponseEntity.ok(ApiResponse.success("Pass cancelled and dedicated bay released", cancelled));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
