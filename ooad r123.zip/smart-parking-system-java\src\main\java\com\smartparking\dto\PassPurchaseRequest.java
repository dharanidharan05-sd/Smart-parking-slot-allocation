package com.smartparking.dto;

import com.smartparking.enums.BillingPlan;
import com.smartparking.enums.VehicleCategory;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class PassPurchaseRequest {

    @NotBlank(message = "Customer name is required")
    private String customerName;

    @NotBlank(message = "Customer phone number is required")
    private String customerPhone;

    @NotBlank(message = "Vehicle registration number is required")
    private String vehicleNumber;

    @NotNull(message = "Category is required")
    private VehicleCategory category = VehicleCategory.FOUR_WHEELER;

    @NotNull(message = "Plan type is required")
    private BillingPlan planType = BillingPlan.MONTHLY; // MONTHLY or YEARLY

    private Long dedicatedSlotId;

    public PassPurchaseRequest() {}

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public VehicleCategory getCategory() { return category; }
    public void setCategory(VehicleCategory category) { this.category = category; }

    public BillingPlan getPlanType() { return planType; }
    public void setPlanType(BillingPlan planType) { this.planType = planType; }

    public Long getDedicatedSlotId() { return dedicatedSlotId; }
    public void setDedicatedSlotId(Long dedicatedSlotId) { this.dedicatedSlotId = dedicatedSlotId; }
}
