package com.smartparking.entity;

import com.smartparking.enums.VehicleCategory;
import javax.persistence.*;

@Entity
@Table(name = "parking_zones")
public class ParkingZone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 30)
    private String code;

    @Column(name = "floor_level", length = 50)
    private String floorLevel = "Ground Level";

    @Enumerated(EnumType.STRING)
    @Column(name = "allowed_category", nullable = false)
    private VehicleCategory allowedCategory;

    @Column(name = "total_capacity")
    private Integer totalCapacity = 10;

    public ParkingZone() {}

    public ParkingZone(String name, String code, String floorLevel, VehicleCategory allowedCategory, Integer totalCapacity) {
        this.name = name;
        this.code = code;
        this.floorLevel = floorLevel;
        this.allowedCategory = allowedCategory;
        this.totalCapacity = totalCapacity;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getFloorLevel() { return floorLevel; }
    public void setFloorLevel(String floorLevel) { this.floorLevel = floorLevel; }

    public VehicleCategory getAllowedCategory() { return allowedCategory; }
    public void setAllowedCategory(VehicleCategory allowedCategory) { this.allowedCategory = allowedCategory; }

    public Integer getTotalCapacity() { return totalCapacity; }
    public void setTotalCapacity(Integer totalCapacity) { this.totalCapacity = totalCapacity; }
}
