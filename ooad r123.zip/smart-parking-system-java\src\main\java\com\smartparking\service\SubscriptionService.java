package com.smartparking.service;

import com.smartparking.dto.PassPurchaseRequest;
import com.smartparking.entity.ParkingSlot;
import com.smartparking.entity.Payment;
import com.smartparking.entity.PricingRule;
import com.smartparking.entity.Subscription;
import com.smartparking.enums.BillingPlan;
import com.smartparking.enums.PaymentMethod;
import com.smartparking.enums.PaymentStatus;
import com.smartparking.enums.SlotStatus;
import com.smartparking.repository.ParkingSlotRepository;
import com.smartparking.repository.PaymentRepository;
import com.smartparking.repository.PricingRuleRepository;
import com.smartparking.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
public class SubscriptionService {

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    @Autowired
    private PricingRuleRepository pricingRuleRepository;

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private AuditService auditService;

    @Transactional
    public Subscription purchasePass(PassPurchaseRequest request) {
        String cleanPlate = request.getVehicleNumber().trim().toUpperCase();

        // 1. Check existing active pass
        Optional<Subscription> existing = subscriptionRepository.findByVehicleNumberAndCategoryAndStatusAndEndDateAfter(
                cleanPlate, request.getCategory(), "ACTIVE", LocalDateTime.now()
        );
        if (existing.isPresent()) {
            throw new IllegalStateException("Vehicle " + cleanPlate + " already has an active " + existing.get().getPlanType() + " pass");
        }

        // 2. Fetch Tariff
        PricingRule rule = pricingRuleRepository.findByCategory(request.getCategory())
                .orElseThrow(() -> new IllegalArgumentException("Tariff rule not found for: " + request.getCategory()));

        BigDecimal baseAmount = (request.getPlanType() == BillingPlan.YEARLY) ? rule.getYearlyRate() : rule.getMonthlyRate();
        BigDecimal tax = baseAmount.multiply(BigDecimal.valueOf(rule.getTaxPercent() / 100.0)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal total = baseAmount.add(tax).setScale(2, RoundingMode.HALF_UP);

        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = (request.getPlanType() == BillingPlan.YEARLY) ? start.plusYears(1) : start.plusMonths(1);

        // 3. Handle optional dedicated slot
        Long dedicatedId = null;
        String dedicatedSlotNumber = null;
        if (request.getDedicatedSlotId() != null) {
            ParkingSlot slot = slotRepository.findById(request.getDedicatedSlotId())
                    .orElseThrow(() -> new IllegalArgumentException("Dedicated bay not found"));
            if (slot.getStatus() != SlotStatus.AVAILABLE) {
                throw new IllegalStateException("Bay " + slot.getSlotNumber() + " cannot be reserved (currently " + slot.getStatus() + ")");
            }
            slot.setStatus(SlotStatus.RESERVED);
            slot.setAssignedVehiclePlate(cleanPlate);
            slotRepository.save(slot);

            dedicatedId = slot.getId();
            dedicatedSlotNumber = slot.getSlotNumber();
        }

        // 4. Create Pass Record
        String passCode = (request.getPlanType() == BillingPlan.YEARLY) ? "PASS-Y" : "PASS-M";
        String dateStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int randCode = (int) (1000 + Math.random() * 9000);
        String passNumber = passCode + "-" + dateStr + "-" + randCode;

        Subscription sub = new Subscription();
        sub.setPassNumber(passNumber);
        sub.setCustomerName(request.getCustomerName().trim());
        sub.setCustomerPhone(request.getCustomerPhone().trim());
        sub.setVehicleNumber(cleanPlate);
        sub.setCategory(request.getCategory());
        sub.setPlanType(request.getPlanType());
        sub.setStartDate(start);
        sub.setEndDate(end);
        sub.setAmount(total);
        sub.setStatus("ACTIVE");
        sub.setDedicatedSlotId(dedicatedId);
        sub.setDedicatedSlotNumber(dedicatedSlotNumber);
        Subscription saved = subscriptionRepository.save(sub);

        // 5. Record Payment
        Payment p = new Payment();
        p.setTransactionId("TXN-SUB-" + passNumber);
        p.setVehicleNumber(cleanPlate);
        p.setCustomerName(request.getCustomerName());
        p.setCustomerPhone(request.getCustomerPhone());
        p.setBaseAmount(baseAmount);
        p.setTaxAmount(tax);
        p.setTotalAmount(total);
        p.setPaymentMethod(PaymentMethod.ONLINE_GATEWAY);
        p.setStatus(PaymentStatus.PAID);
        paymentRepository.save(p);

        auditService.logEvent("PASS_PURCHASED", "SUBSCRIPTION", passNumber, null, total.toString(), "Pass purchased for " + cleanPlate);
        return saved;
    }

    public List<Subscription> getAllPasses() {
        return subscriptionRepository.findAll();
    }

    @Transactional
    public Subscription cancelPass(Long id, String reason) {
        Subscription sub = subscriptionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Pass not found with ID: " + id));

        sub.setStatus("CANCELLED");

        // Release dedicated slot if reserved
        if (sub.getDedicatedSlotId() != null) {
            Optional<ParkingSlot> optSlot = slotRepository.findById(sub.getDedicatedSlotId());
            if (optSlot.isPresent()) {
                ParkingSlot slot = optSlot.get();
                slot.setStatus(SlotStatus.AVAILABLE);
                slot.setAssignedVehiclePlate(null);
                slotRepository.save(slot);
            }
        }

        auditService.logEvent("PASS_CANCELLED", "SUBSCRIPTION", sub.getPassNumber(), "ACTIVE", "CANCELLED", reason);
        return subscriptionRepository.save(sub);
    }
}
