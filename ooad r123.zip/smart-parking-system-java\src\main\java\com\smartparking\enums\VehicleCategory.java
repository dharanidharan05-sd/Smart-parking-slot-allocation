package com.smartparking.enums;

public enum VehicleCategory {
    TWO_WHEELER("Two-Wheeler (Bike / Scooter)", 2.5, 1.2),
    FOUR_WHEELER("Four-Wheeler (Car / Sedan / SUV)", 5.0, 2.4),
    COMMERCIAL("Commercial (Van / Mini Truck)", 6.5, 2.8),
    HEAVY("Heavy Vehicle (Bus / Lorry / Truck)", 12.0, 3.2);

    private final String displayName;
    private final double defaultLength;
    private final double defaultWidth;

    VehicleCategory(String displayName, double defaultLength, double defaultWidth) {
        this.displayName = displayName;
        this.defaultLength = defaultLength;
        this.defaultWidth = defaultWidth;
    }

    public String getDisplayName() {
        return displayName;
    }

    public double getDefaultLength() {
        return defaultLength;
    }

    public double getDefaultWidth() {
        return defaultWidth;
    }
}
