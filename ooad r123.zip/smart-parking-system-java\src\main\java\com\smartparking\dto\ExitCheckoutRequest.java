package com.smartparking.dto;

import com.smartparking.enums.PaymentMethod;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ExitCheckoutRequest {

    @NotBlank(message = "Ticket number is required")
    private String ticketNumber;

    @NotNull(message = "Payment method is required")
    private PaymentMethod paymentMethod = PaymentMethod.CASH;

    private Double customDiscountPercent = 0.0;
    private String notes = "";

    public ExitCheckoutRequest() {}

    public String getTicketNumber() { return ticketNumber; }
    public void setTicketNumber(String ticketNumber) { this.ticketNumber = ticketNumber; }

    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }

    public Double getCustomDiscountPercent() { return customDiscountPercent; }
    public void setCustomDiscountPercent(Double customDiscountPercent) { this.customDiscountPercent = customDiscountPercent; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
