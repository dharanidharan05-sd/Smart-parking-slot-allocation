@echo off
title Smart Parking System - Public & Local Network Sharing
color 0b
echo ===============================================================================
echo            SMART PARKING SYSTEM - MULTI-USER PUBLIC LINK SHARING
echo ===============================================================================
echo.
echo 1. Finding your Local Wi-Fi Network IP Address...

set "LOCAL_IP=127.0.0.1"
for /f "tokens=4" %%a in ('route print ^| findstr 0.0.0.0 ^| findstr /v "0.0.0.0/0"') do (
    if not "%%a"=="0.0.0.0" set "LOCAL_IP=%%a"
)

echo.
echo ===============================================================================
echo  [METHOD 1] 100%% RELIABLE LOCAL WI-FI / HOTSPOT LINK (ZERO TUNNEL ERRORS!)
echo ===============================================================================
echo  Your Local Wi-Fi URL:
echo  --^>  http://%LOCAL_IP%:8080
echo.
echo  * Share this URL with anyone connected to the same Wi-Fi or Mobile Hotspot!
echo  * Works on Android, iPhone, iPad, Mac, and Windows laptops.
echo  * NO tunnel required, NO registration, NEVER expires, 0%% connection errors!
echo ===============================================================================
echo.

echo ===============================================================================
echo  [METHOD 2] WORLDWIDE PUBLIC INTERNET LINK (CLOUDFLARE QUICK TUNNEL)
echo ===============================================================================
echo  To share across the world over 4G/5G mobile internet, we will start a
echo  high-speed Cloudflare Quick Tunnel (no account required, free HTTPS URL).
echo.
echo  Checking Node.js / NPX for tunnel...
where npx >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo  Starting Cloudflare Quick Tunnel...
    echo  (Please keep this window open while sharing!)
    echo.
    npx -y cloudflared tunnel --url http://localhost:8080
    goto DONE
)

where ssh >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo  Starting Pinggy Public Tunnel via SSH...
    ssh -p 443 -R0:localhost:8080 -o StrictHostKeyChecking=no a.pinggy.io
    goto DONE
)

echo  Local Wi-Fi link is active at: http://%LOCAL_IP%:8080
:DONE
pause
