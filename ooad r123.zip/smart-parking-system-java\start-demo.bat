@echo off
title Launch Smart Parking System
echo ===============================================================================
echo     LAUNCHING SMART PARKING SYSTEM (SPRING BOOT + EMBEDDED DASHBOARD)
echo ===============================================================================
echo 1. Starting Spring Boot Backend in a new window...
start "Smart Parking Backend" cmd /c "run-backend.bat"
echo 2. Waiting 8 seconds for Spring Boot server to initialize...
timeout /t 8 /nobreak >nul
echo 3. Opening web browser at http://localhost:8080 ...
start http://localhost:8080
echo.
echo ===============================================================================
echo  Application is live at:     http://localhost:8080
echo  Mobile/Wi-Fi Network link:  http://192.168.230.240:8080
echo  H2 Database Console:        http://localhost:8080/h2-console
echo  To share worldwide:         run share-public-link.bat
echo ===============================================================================
pause
