package com.smartparking.entity;

import com.smartparking.enums.VehicleCategory;
import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "pricing_rules")
public class PricingRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, unique = true, length = 30)
    private VehicleCategory category;

    @Column(name = "hourly_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal hourlyRate;

    @Column(name = "daily_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal dailyRate;

    @Column(name = "monthly_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal monthlyRate;

    @Column(name = "yearly_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal yearlyRate;

    @Column(name = "grace_period_minutes")
    private Integer gracePeriodMinutes = 15;

    @Column(name = "overtime_rate_per_hour", nullable = false, precision = 10, scale = 2)
    private BigDecimal overtimeRatePerHour;

    @Column(name = "tax_percent")
    private Double taxPercent = 18.0;

    @Column(name = "discount_percent")
    private Double discountPercent = 0.0;

    @Column(name = "effective_date")
    private LocalDateTime effectiveDate = LocalDateTime.now();

    @Column(name = "last_update_reason", length = 255)
    private String lastUpdateReason = "Initial setup";

    @Column(name = "updated_by", length = 100)
    private String updatedBy = "System Administrator";

    public PricingRule() {}

    public PricingRule(VehicleCategory category, BigDecimal hourlyRate, BigDecimal dailyRate, 
                       BigDecimal monthlyRate, BigDecimal yearlyRate, Integer gracePeriodMinutes, 
                       BigDecimal overtimeRatePerHour, Double taxPercent) {
        this.category = category;
        this.hourlyRate = hourlyRate;
        this.dailyRate = dailyRate;
        this.monthlyRate = monthlyRate;
        this.yearlyRate = yearlyRate;
        this.gracePeriodMinutes = gracePeriodMinutes;
        this.overtimeRatePerHour = overtimeRatePerHour;
        this.taxPercent = taxPercent;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public VehicleCategory getCategory() { return category; }
    public void setCategory(VehicleCategory category) { this.category = category; }

    public BigDecimal getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(BigDecimal hourlyRate) { this.hourlyRate = hourlyRate; }

    public BigDecimal getDailyRate() { return dailyRate; }
    public void setDailyRate(BigDecimal dailyRate) { this.dailyRate = dailyRate; }

    public BigDecimal getMonthlyRate() { return monthlyRate; }
    public void setMonthlyRate(BigDecimal monthlyRate) { this.monthlyRate = monthlyRate; }

    public BigDecimal getYearlyRate() { return yearlyRate; }
    public void setYearlyRate(BigDecimal yearlyRate) { this.yearlyRate = yearlyRate; }

    public Integer getGracePeriodMinutes() { return gracePeriodMinutes; }
    public void setGracePeriodMinutes(Integer gracePeriodMinutes) { this.gracePeriodMinutes = gracePeriodMinutes; }

    public BigDecimal getOvertimeRatePerHour() { return overtimeRatePerHour; }
    public void setOvertimeRatePerHour(BigDecimal overtimeRatePerHour) { this.overtimeRatePerHour = overtimeRatePerHour; }

    public Double getTaxPercent() { return taxPercent; }
    public void setTaxPercent(Double taxPercent) { this.taxPercent = taxPercent; }

    public Double getDiscountPercent() { return discountPercent; }
    public void setDiscountPercent(Double discountPercent) { this.discountPercent = discountPercent; }

    public LocalDateTime getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(LocalDateTime effectiveDate) { this.effectiveDate = effectiveDate; }

    public String getLastUpdateReason() { return lastUpdateReason; }
    public void setLastUpdateReason(String lastUpdateReason) { this.lastUpdateReason = lastUpdateReason; }

    public String getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }
}
