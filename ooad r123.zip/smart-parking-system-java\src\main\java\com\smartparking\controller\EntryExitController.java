package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.dto.EntryRequest;
import com.smartparking.dto.ExitCheckoutRequest;
import com.smartparking.service.EntryExitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping("/api/parking")
@CrossOrigin(origins = "*")
public class EntryExitController {

    @Autowired
    private EntryExitService entryExitService;

    @PostMapping("/entry")
    public ResponseEntity<ApiResponse<Map<String, Object>>> registerEntry(@Valid @RequestBody EntryRequest request) {
        try {
            Map<String, Object> result = entryExitService.registerVehicleEntry(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Entry pass generated successfully", result));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/session/{identifier}")
    public ResponseEntity<ApiResponse<Map<String, Object>>> previewSession(@PathVariable String identifier) {
        try {
            Map<String, Object> res = entryExitService.previewCheckout(identifier);
            return ResponseEntity.ok(ApiResponse.success(res));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/exit")
    public ResponseEntity<ApiResponse<Map<String, Object>>> processExit(@Valid @RequestBody ExitCheckoutRequest request) {
        try {
            Map<String, Object> receipt = entryExitService.processVehicleExit(request);
            return ResponseEntity.ok(ApiResponse.success("Vehicle exit and payment cleared", receipt));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
