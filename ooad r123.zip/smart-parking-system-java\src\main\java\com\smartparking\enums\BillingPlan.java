package com.smartparking.enums;

public enum BillingPlan {
    HOURLY,
    DAILY,
    MONTHLY,
    YEARLY
}
