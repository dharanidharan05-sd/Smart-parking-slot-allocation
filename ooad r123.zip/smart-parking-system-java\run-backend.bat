@echo off
title Smart Parking System - Spring Boot Backend
echo ===============================================================================
echo       SMART PARKING SLOT ALLOCATION ^& MANAGEMENT SYSTEM (FULL JAVA)
echo ===============================================================================
echo Starting Spring Boot on http://localhost:8080 ...
echo Database: In-memory H2 (zero configuration needed)
echo Profile:  h2
echo.

REM Detect JDK from VS Code RedHat Java Extension if JAVA_HOME is not a JDK
if exist "%USERPROFILE%\.vscode\extensions\redhat.java-1.58.0-win32-x64\jre\25.0.4.1-win32-x86_64\bin\javac.exe" (
    set "JAVA_HOME=%USERPROFILE%\.vscode\extensions\redhat.java-1.58.0-win32-x64\jre\25.0.4.1-win32-x86_64"
    set "PATH=%USERPROFILE%\.vscode\extensions\redhat.java-1.58.0-win32-x64\jre\25.0.4.1-win32-x86_64\bin;%PATH%"
    goto JDK_FOUND
)

where javac >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    for /d %%E in ("%USERPROFILE%\.vscode\extensions\redhat.java-*") do (
        for /d %%J in ("%%E\jre\*") do (
            if exist "%%J\bin\javac.exe" (
                set "JAVA_HOME=%%J"
                set "PATH=%%J\bin;%PATH%"
                goto JDK_FOUND
            )
        )
    )
)
:JDK_FOUND

set "MAVEN_OPTS=-Dhttps.protocols=TLSv1.2 -Djdk.tls.client.protocols=TLSv1.2"

REM Detect Maven
where mvn >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set MVN_CMD=mvn
    goto RUN
)

if exist "%USERPROFILE%\.vscode\extensions\oracle.oracle-java-27.0.0\nbcode\java\maven\bin\mvn.cmd" (
    set MVN_CMD="%USERPROFILE%\.vscode\extensions\oracle.oracle-java-27.0.0\nbcode\java\maven\bin\mvn.cmd"
    goto RUN
)

for /d %%D in ("%USERPROFILE%\.vscode\extensions\oracle.oracle-java-*") do (
    if exist "%%D\nbcode\java\maven\bin\mvn.cmd" (
        set MVN_CMD="%%D\nbcode\java\maven\bin\mvn.cmd"
        goto RUN
    )
)

echo [ERROR] Maven not found! Please install Maven or run via VS Code with Java Extension Pack.
pause
exit /b 1

:RUN
echo Java:  %JAVA_HOME%
echo Maven: %MVN_CMD%
%MVN_CMD% spring-boot:run -Dspring-boot.run.profiles=h2
pause
