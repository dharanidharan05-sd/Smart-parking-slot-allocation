package com.smartparking.controller;

import com.smartparking.dto.EntryRequest;
import com.smartparking.dto.ExitCalculationDTO;
import com.smartparking.dto.ExitCheckoutRequest;
import com.smartparking.entity.ParkingSession;
import com.smartparking.entity.ParkingSlot;
import com.smartparking.enums.BillingPlan;
import com.smartparking.enums.PaymentMethod;
import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.repository.ParkingSessionRepository;
import com.smartparking.repository.ParkingSlotRepository;
import com.smartparking.service.DashboardService;
import com.smartparking.service.EntryExitService;
import com.smartparking.service.SlotAllocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Controller providing 100% backward-compatibility for legacy frontend scripts
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class LegacyCompatibilityController {

    @Autowired
    private ParkingSlotRepository slotRepository;

    @Autowired
    private ParkingSessionRepository sessionRepository;

    @Autowired
    private SlotAllocationService slotAllocationService;

    @Autowired
    private EntryExitService entryExitService;

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/slots")
    public ResponseEntity<List<ParkingSlot>> getAllSlots() {
        return ResponseEntity.ok(slotRepository.findAll());
    }

    @GetMapping("/slots/floor/{floor}")
    public ResponseEntity<List<ParkingSlot>> getSlotsByFloor(@PathVariable Integer floor) {
        return ResponseEntity.ok(slotRepository.findAll());
    }

    @GetMapping("/slots/nearest")
    public ResponseEntity<?> getNearestSlot(@RequestParam(required = false) String vehicleType) {
        VehicleCategory cat = VehicleCategory.FOUR_WHEELER;
        if (vehicleType != null) {
            try {
                if (vehicleType.toUpperCase().contains("TWO") || vehicleType.toUpperCase().contains("BIKE")) {
                    cat = VehicleCategory.TWO_WHEELER;
                } else if (vehicleType.toUpperCase().contains("HEAVY") || vehicleType.toUpperCase().contains("BUS")) {
                    cat = VehicleCategory.HEAVY;
                } else if (vehicleType.toUpperCase().contains("COMMERCIAL") || vehicleType.toUpperCase().contains("VAN")) {
                    cat = VehicleCategory.COMMERCIAL;
                }
            } catch (Exception ignored) {}
        }

        List<ParkingSlot> candidates = slotRepository.findByCategoryAndStatusOrderByWalkDistanceUnitsAsc(cat, SlotStatus.AVAILABLE);
        if (!candidates.isEmpty()) {
            return ResponseEntity.ok(candidates.get(0));
        }

        Map<String, String> err = new HashMap<>();
        err.put("message", "No available slot found for " + cat);
        return ResponseEntity.status(404).body(err);
    }

    @PostMapping("/bookings")
    public ResponseEntity<?> legacyBooking(@RequestBody Map<String, Object> body) {
        try {
            EntryRequest req = new EntryRequest();
            req.setVehicleNumber((String) body.getOrDefault("vehicleNumber", "KA01AB" + (int)(1000 + Math.random()*9000)));
            req.setCustomerName((String) body.getOrDefault("driverName", "Driver"));
            req.setCustomerPhone((String) body.getOrDefault("driverPhone", "+91 9876543210"));

            String vType = (String) body.get("vehicleType");
            if (vType != null && (vType.contains("TWO") || vType.contains("BIKE"))) {
                req.setCategory(VehicleCategory.TWO_WHEELER);
            } else if (vType != null && (vType.contains("HEAVY") || vType.contains("BUS"))) {
                req.setCategory(VehicleCategory.HEAVY);
            } else if (vType != null && (vType.contains("COMMERCIAL") || vType.contains("VAN"))) {
                req.setCategory(VehicleCategory.COMMERCIAL);
            } else {
                req.setCategory(VehicleCategory.FOUR_WHEELER);
            }

            if (body.get("slotId") != null) {
                try {
                    req.setSlotId(Long.valueOf(body.get("slotId").toString()));
                } catch (Exception ignored) {}
            }

            Map<String, Object> result = entryExitService.registerVehicleEntry(req);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, String> err = new HashMap<>();
            err.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(err);
        }
    }

    @GetMapping("/bookings/calculate-exit")
    public ResponseEntity<?> calculateExit(@RequestParam String query) {
        try {
            Map<String, Object> preview = entryExitService.previewCheckout(query);
            return ResponseEntity.ok(preview);
        } catch (Exception e) {
            Map<String, String> err = new HashMap<>();
            err.put("error", e.getMessage());
            return ResponseEntity.status(404).body(err);
        }
    }

    @PostMapping("/payments/process")
    public ResponseEntity<?> processPayment(@RequestBody Map<String, Object> body) {
        try {
            ExitCheckoutRequest req = new ExitCheckoutRequest();
            req.setTicketNumber((String) body.get("ticketNumber"));
            String method = (String) body.getOrDefault("paymentMethod", "CASH");
            try {
                req.setPaymentMethod(PaymentMethod.valueOf(method.toUpperCase()));
            } catch (Exception e) {
                req.setPaymentMethod(PaymentMethod.CASH);
            }

            Map<String, Object> receipt = entryExitService.processVehicleExit(req);
            return ResponseEntity.ok(receipt);
        } catch (Exception e) {
            Map<String, String> err = new HashMap<>();
            err.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(err);
        }
    }

    @GetMapping("/admin/stats")
    public ResponseEntity<?> getAdminStats() {
        return ResponseEntity.ok(dashboardService.getMetrics());
    }

    @PostMapping("/admin/login")
    public ResponseEntity<?> adminLogin(@RequestBody Map<String, String> creds) {
        String email = creds.getOrDefault("email", creds.getOrDefault("username", "")).trim();
        String pass = creds.getOrDefault("password", "").trim();

        if (("admin@smartparking.com".equalsIgnoreCase(email) || "admin".equalsIgnoreCase(email) || "admin@parking.com".equalsIgnoreCase(email)) 
                && ("admin123".equals(pass) || "Admin@12345".equals(pass))) {
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("message", "Admin authentication successful");
            resp.put("adminEmail", "admin@smartparking.com");
            resp.put("token", "sim_admin_token_" + System.currentTimeMillis());
            return ResponseEntity.ok(resp);
        }

        Map<String, String> err = new HashMap<>();
        err.put("error", "Invalid Admin credentials. Use admin@smartparking.com / admin123");
        return ResponseEntity.status(401).body(err);
    }
}
