package com.smartparking.enums;

public enum SlotStatus {
    AVAILABLE,    // Green
    OCCUPIED,     // Red
    RESERVED,     // Yellow
    MAINTENANCE,  // Blue
    DISABLED      // Grey
}
