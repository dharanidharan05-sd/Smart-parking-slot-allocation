/**
 * Smart Parking System - Dual-Mode API Client
 * Seamlessly connects to Spring Boot REST APIs (/api/...)
 * Automatically falls back to high-fidelity 4-Floor local simulation if backend is offline.
 */

const API_BASE = window.location.origin.includes('localhost:8080')
  ? '/api'
  : 'http://localhost:8080/api';

const ApiClient = {
  isBackendAvailable: null,

  async checkBackend() {
    if (this.isBackendAvailable !== null) return this.isBackendAvailable;
    try {
      const res = await fetch(`${API_BASE}/slots`, { method: 'GET', credentials: 'omit' });
      this.isBackendAvailable = res.ok;
    } catch (e) {
      this.isBackendAvailable = false;
    }
    return this.isBackendAvailable;
  },

  async getSlots() {
    if (await this.checkBackend()) {
      const res = await fetch(`${API_BASE}/slots`);
      if (res.ok) return await res.json();
    }
    return LocalStorageSimulator.getSlots();
  },

  async getNearestSlot(vehicleType) {
    if (await this.checkBackend()) {
      const res = await fetch(`${API_BASE}/slots/nearest?vehicleType=${encodeURIComponent(vehicleType || '')}`);
      if (res.ok) return await res.json();
    }
    return LocalStorageSimulator.getNearestSlot(vehicleType);
  },

  async createBooking(bookingData) {
    if (await this.checkBackend()) {
      const res = await fetch(`${API_BASE}/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Booking failed');
      return data;
    }
    return LocalStorageSimulator.createBooking(bookingData);
  },

  async calculateExitBill(query, planType = 'hour', planValue = 1, simulatedMinutes = null) {
    if (await this.checkBackend()) {
      try {
        const res = await fetch(`${API_BASE}/bookings/calculate-exit?query=${encodeURIComponent(query)}`);
        if (res.ok) {
          const data = await res.json();
          return LocalStorageSimulator.calculateExitBill(query, planType, planValue, simulatedMinutes);
        }
      } catch (e) {
        // Fall back to local simulator
      }
    }
    return LocalStorageSimulator.calculateExitBill(query, planType, planValue, simulatedMinutes);
  },

  async processPayment(paymentData) {
    if (await this.checkBackend()) {
      try {
        const res = await fetch(`${API_BASE}/payments/process`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(paymentData)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        // Fall back to local simulator
      }
    }
    return LocalStorageSimulator.processPayment(paymentData);
  },

  async adminLogin(credentials) {
    if (await this.checkBackend()) {
      try {
        const res = await fetch(`${API_BASE}/admin/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(credentials)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        // Fall back to local simulator
      }
    }
    return LocalStorageSimulator.adminLogin(credentials);
  },

  async getAdminStats() {
    if (await this.checkBackend()) {
      try {
        const res = await fetch(`${API_BASE}/admin/stats`);
        if (res.ok) return await res.json();
      } catch (e) {
        // Fall back to local simulator
      }
    }
    return LocalStorageSimulator.getAdminStats();
  },

  async getTariffs() {
    return LocalStorageSimulator.getTariffs();
  },

  async updateTariffs(rates) {
    if (await this.checkBackend()) {
      try {
        await fetch(`${API_BASE}/admin/rates`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(rates)
        });
      } catch (e) {
        // Ignore backend error and sync locally
      }
    }
    return LocalStorageSimulator.updateTariffs(rates);
  },

  async toggleSlotMaintenance(slotNumber) {
    return LocalStorageSimulator.toggleSlotMaintenance(slotNumber);
  },

  async toggleSlotEv(slotNumber) {
    return LocalStorageSimulator.toggleSlotEv(slotNumber);
  },

  async updateAdminPassword(newPassword) {
    return LocalStorageSimulator.updateAdminPassword(newPassword);
  }
};

/**
 * High-fidelity 4-Floor Simulator with 40 Slots and Incoming/Outgoing Tracking
 */
const LocalStorageSimulator = {
  init(force = false) {
    if (force || !localStorage.getItem('SP_SLOTS_V4')) {
      const slots = [];
      
      // Floor 0: Ground Floor (G-01 to G-10)
      slots.push({ id: 1, slotNumber: 'G-01', floorLevel: 0, slotType: 'EV', status: 'OCCUPIED', distanceScore: 5, baseHourlyRate: 60.0, hasEvCharger: true, vehicleNumber: 'KA-01-MJ-2024' });
      slots.push({ id: 2, slotNumber: 'G-02', floorLevel: 0, slotType: 'EV', status: 'AVAILABLE', distanceScore: 8, baseHourlyRate: 60.0, hasEvCharger: true });
      slots.push({ id: 3, slotNumber: 'G-03', floorLevel: 0, slotType: 'FOUR_WHEELER', status: 'OCCUPIED', distanceScore: 12, baseHourlyRate: 50.0, hasEvCharger: false, vehicleNumber: 'DL-03-CX-7788' });
      slots.push({ id: 4, slotNumber: 'G-04', floorLevel: 0, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 15, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 5, slotNumber: 'G-05', floorLevel: 0, slotType: 'FOUR_WHEELER', status: 'RESERVED', distanceScore: 18, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 6, slotNumber: 'G-06', floorLevel: 0, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 22, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 7, slotNumber: 'G-07', floorLevel: 0, slotType: 'TWO_WHEELER', status: 'OCCUPIED', distanceScore: 25, baseHourlyRate: 20.0, hasEvCharger: false, vehicleNumber: 'MH-12-AB-9900' });
      slots.push({ id: 8, slotNumber: 'G-08', floorLevel: 0, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 28, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 9, slotNumber: 'G-09', floorLevel: 0, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 32, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 10, slotNumber: 'G-10', floorLevel: 0, slotType: 'HEAVY_VEHICLE', status: 'AVAILABLE', distanceScore: 38, baseHourlyRate: 80.0, hasEvCharger: false });

      // Floor 1: Floor 1 (F1-01 to F1-10)
      slots.push({ id: 11, slotNumber: 'F1-01', floorLevel: 1, slotType: 'EV', status: 'AVAILABLE', distanceScore: 50, baseHourlyRate: 60.0, hasEvCharger: true });
      slots.push({ id: 12, slotNumber: 'F1-02', floorLevel: 1, slotType: 'EV', status: 'OCCUPIED', distanceScore: 55, baseHourlyRate: 60.0, hasEvCharger: true, vehicleNumber: 'TS-08-EV-3344' });
      slots.push({ id: 13, slotNumber: 'F1-03', floorLevel: 1, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 60, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 14, slotNumber: 'F1-04', floorLevel: 1, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 65, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 15, slotNumber: 'F1-05', floorLevel: 1, slotType: 'FOUR_WHEELER', status: 'OCCUPIED', distanceScore: 70, baseHourlyRate: 50.0, hasEvCharger: false, vehicleNumber: 'HR-26-DK-5511' });
      slots.push({ id: 16, slotNumber: 'F1-06', floorLevel: 1, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 75, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 17, slotNumber: 'F1-07', floorLevel: 1, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 80, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 18, slotNumber: 'F1-08', floorLevel: 1, slotType: 'TWO_WHEELER', status: 'RESERVED', distanceScore: 85, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 19, slotNumber: 'F1-09', floorLevel: 1, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 90, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 20, slotNumber: 'F1-10', floorLevel: 1, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 95, baseHourlyRate: 50.0, hasEvCharger: false });

      // Floor 2: Floor 2 (F2-01 to F2-10)
      slots.push({ id: 21, slotNumber: 'F2-01', floorLevel: 2, slotType: 'EV', status: 'AVAILABLE', distanceScore: 100, baseHourlyRate: 60.0, hasEvCharger: true });
      slots.push({ id: 22, slotNumber: 'F2-02', floorLevel: 2, slotType: 'EV', status: 'AVAILABLE', distanceScore: 105, baseHourlyRate: 60.0, hasEvCharger: true });
      slots.push({ id: 23, slotNumber: 'F2-03', floorLevel: 2, slotType: 'FOUR_WHEELER', status: 'OCCUPIED', distanceScore: 110, baseHourlyRate: 50.0, hasEvCharger: false, vehicleNumber: 'GJ-01-XY-5522' });
      slots.push({ id: 24, slotNumber: 'F2-04', floorLevel: 2, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 115, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 25, slotNumber: 'F2-05', floorLevel: 2, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 120, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 26, slotNumber: 'F2-06', floorLevel: 2, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 125, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 27, slotNumber: 'F2-07', floorLevel: 2, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 130, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 28, slotNumber: 'F2-08', floorLevel: 2, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 135, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 29, slotNumber: 'F2-09', floorLevel: 2, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 140, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 30, slotNumber: 'F2-10', floorLevel: 2, slotType: 'HEAVY_VEHICLE', status: 'AVAILABLE', distanceScore: 145, baseHourlyRate: 80.0, hasEvCharger: false });

      // Floor 3: Floor 3 (F3-01 to F3-10)
      slots.push({ id: 31, slotNumber: 'F3-01', floorLevel: 3, slotType: 'EV', status: 'AVAILABLE', distanceScore: 150, baseHourlyRate: 60.0, hasEvCharger: true });
      slots.push({ id: 32, slotNumber: 'F3-02', floorLevel: 3, slotType: 'EV', status: 'AVAILABLE', distanceScore: 155, baseHourlyRate: 60.0, hasEvCharger: true });
      slots.push({ id: 33, slotNumber: 'F3-03', floorLevel: 3, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 160, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 34, slotNumber: 'F3-04', floorLevel: 3, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 165, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 35, slotNumber: 'F3-05', floorLevel: 3, slotType: 'FOUR_WHEELER', status: 'OCCUPIED', distanceScore: 170, baseHourlyRate: 50.0, hasEvCharger: false, vehicleNumber: 'UP-32-BZ-1122' });
      slots.push({ id: 36, slotNumber: 'F3-06', floorLevel: 3, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 175, baseHourlyRate: 50.0, hasEvCharger: false });
      slots.push({ id: 37, slotNumber: 'F3-07', floorLevel: 3, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 180, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 38, slotNumber: 'F3-08', floorLevel: 3, slotType: 'TWO_WHEELER', status: 'RESERVED', distanceScore: 185, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 39, slotNumber: 'F3-09', floorLevel: 3, slotType: 'TWO_WHEELER', status: 'AVAILABLE', distanceScore: 190, baseHourlyRate: 20.0, hasEvCharger: false });
      slots.push({ id: 40, slotNumber: 'F3-10', floorLevel: 3, slotType: 'FOUR_WHEELER', status: 'AVAILABLE', distanceScore: 195, baseHourlyRate: 50.0, hasEvCharger: false });

      localStorage.setItem('SP_SLOTS_V4', JSON.stringify(slots));

      // Realistic Active Bookings with past entry times (so duration is at least 1-3 hours)
      const now = Date.now();
      const bookings = [
        { id: 1, bookingCode: 'SP-BK-20261014-001', slotNumber: 'G-01', floorLevel: 0, vehicleNumber: 'KA-01-MJ-2024', ownerName: 'Rajesh Sharma', vehicleType: 'EV', contactNumber: '9876543210', entryTime: new Date(now - 150 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 60.0 },
        { id: 2, bookingCode: 'SP-BK-20261014-002', slotNumber: 'G-03', floorLevel: 0, vehicleNumber: 'DL-03-CX-7788', ownerName: 'Priya Verma', vehicleType: 'FOUR_WHEELER', contactNumber: '9812345678', entryTime: new Date(now - 95 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 50.0 },
        { id: 3, bookingCode: 'SP-BK-20261014-003', slotNumber: 'G-07', floorLevel: 0, vehicleNumber: 'MH-12-AB-9900', ownerName: 'Amit Patel', vehicleType: 'TWO_WHEELER', contactNumber: '9765432109', entryTime: new Date(now - 50 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 20.0 },
        { id: 4, bookingCode: 'SP-BK-20261014-004', slotNumber: 'F1-02', floorLevel: 1, vehicleNumber: 'TS-08-EV-3344', ownerName: 'Dr. Sneha Reddy', vehicleType: 'EV', contactNumber: '9988776655', entryTime: new Date(now - 210 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 60.0 },
        { id: 5, bookingCode: 'SP-BK-20261014-005', slotNumber: 'F1-05', floorLevel: 1, vehicleNumber: 'HR-26-DK-5511', ownerName: 'Vikramaditya Roy', vehicleType: 'FOUR_WHEELER', contactNumber: '9123456780', entryTime: new Date(now - 125 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 50.0 },
        { id: 6, bookingCode: 'SP-BK-20261014-006', slotNumber: 'F2-03', floorLevel: 2, vehicleNumber: 'GJ-01-XY-5522', ownerName: 'Meera Deshmukh', vehicleType: 'FOUR_WHEELER', contactNumber: '9822334455', entryTime: new Date(now - 70 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 50.0 },
        { id: 7, bookingCode: 'SP-BK-20261014-007', slotNumber: 'F3-05', floorLevel: 3, vehicleNumber: 'UP-32-BZ-1122', ownerName: 'Rohan Gupta', vehicleType: 'FOUR_WHEELER', contactNumber: '9911223344', entryTime: new Date(now - 180 * 60000).toISOString(), status: 'ACTIVE', hourlyRate: 50.0 },
        // 1 Completed Outgoing Session
        { id: 8, bookingCode: 'SP-BK-20261014-008', slotNumber: 'G-04', floorLevel: 0, vehicleNumber: 'TN-09-PQ-8822', ownerName: 'Karthik Raja', vehicleType: 'FOUR_WHEELER', contactNumber: '9443322110', entryTime: new Date(now - 300 * 60000).toISOString(), exitTime: new Date(now - 60 * 60000).toISOString(), durationMinutes: 240, status: 'COMPLETED', hourlyRate: 50.0 }
      ];
      localStorage.setItem('SP_BOOKINGS_V4', JSON.stringify(bookings));

      const payments = [
        { receiptNumber: 'REC-20261014-0891', transactionId: 'TXN-UPI-9928172', bookingCode: 'SP-BK-20261014-008', vehicleNumber: 'TN-09-PQ-8822', slotNumber: 'G-04', amount: 200.0, paymentMethod: 'UPI', paymentStatus: 'PAID', paymentTime: new Date(now - 60 * 60000).toISOString() }
      ];
      localStorage.setItem('SP_PAYMENTS_V4', JSON.stringify(payments));

      const tariffs = {
        RATE_FOUR_WHEELER_HOUR: 50,
        RATE_FOUR_WHEELER_DAY: 400,
        RATE_FOUR_WHEELER_MONTH: 3500,
        RATE_FOUR_WHEELER_YEAR: 32000,

        RATE_TWO_WHEELER_HOUR: 20,
        RATE_TWO_WHEELER_DAY: 150,
        RATE_TWO_WHEELER_MONTH: 1200,
        RATE_TWO_WHEELER_YEAR: 10000,

        RATE_EV_HOUR: 60,
        RATE_EV_DAY: 500,
        RATE_EV_MONTH: 4500,
        RATE_EV_YEAR: 40000,

        RATE_HEAVY_VEHICLE_HOUR: 80,
        RATE_HEAVY_VEHICLE_DAY: 700,
        RATE_HEAVY_VEHICLE_MONTH: 6000,
        RATE_HEAVY_VEHICLE_YEAR: 55000,

        RATE_FOUR_WHEELER: 50,
        RATE_TWO_WHEELER: 20,
        RATE_EV: 60,
        RATE_HEAVY_VEHICLE: 80
      };
      localStorage.setItem('SP_TARIFFS_V4', JSON.stringify(tariffs));
    }
  },

  getSlots() {
    this.init();
    return JSON.parse(localStorage.getItem('SP_SLOTS_V4') || '[]');
  },

  getNearestSlot(vehicleType) {
    const slots = this.getSlots().filter(s => s.status === 'AVAILABLE');
    if (vehicleType) {
      const match = slots.find(s => s.slotType === vehicleType);
      if (match) return match;
    }
    return slots[0] || null;
  },

  createBooking(req) {
    this.init();
    const slots = this.getSlots();
    const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');

    const reg = req.vehicleNumber.trim().toUpperCase();
    const existing = bookings.find(b => b.vehicleNumber === reg && b.status === 'ACTIVE');
    if (existing) {
      throw new Error(`Vehicle ${reg} is ALREADY parked in Bay ${existing.slotNumber}. Please settle exit bill first.`);
    }

    let targetSlot = null;
    if (req.preferredSlotNumber) {
      targetSlot = slots.find(s => s.slotNumber === req.preferredSlotNumber);
      if (!targetSlot || targetSlot.status !== 'AVAILABLE') {
        throw new Error(`Slot ${req.preferredSlotNumber} is no longer available.`);
      }
    } else {
      targetSlot = this.getNearestSlot(req.vehicleType);
      if (!targetSlot) {
        throw new Error('All parking slots are fully occupied.');
      }
    }

    // 🔴 Mark slot OCCUPIED
    targetSlot.status = 'OCCUPIED';
    targetSlot.vehicleNumber = reg;
    localStorage.setItem('SP_SLOTS_V4', JSON.stringify(slots));

    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randCode = Math.random().toString(36).substring(2, 6).toUpperCase();
    const bookingCode = `SP-BK-${dateStr}-${randCode}`;

    const newBooking = {
      id: Date.now(),
      bookingCode,
      slotNumber: targetSlot.slotNumber,
      floorLevel: targetSlot.floorLevel,
      vehicleNumber: reg,
      ownerName: req.ownerName,
      vehicleType: req.vehicleType,
      contactNumber: req.contactNumber,
      entryTime: new Date().toISOString(),
      status: 'ACTIVE',
      hourlyRate: targetSlot.baseHourlyRate,
      distanceScore: targetSlot.distanceScore
    };

    bookings.unshift(newBooking);
    localStorage.setItem('SP_BOOKINGS_V4', JSON.stringify(bookings));

    return {
      bookingCode,
      slotNumber: targetSlot.slotNumber,
      floorLevel: targetSlot.floorLevel,
      vehicleNumber: reg,
      ownerName: req.ownerName,
      vehicleType: req.vehicleType,
      contactNumber: req.contactNumber,
      entryTime: newBooking.entryTime,
      hourlyRate: targetSlot.baseHourlyRate,
      distanceScore: targetSlot.distanceScore,
      message: `Bay ${targetSlot.slotNumber} (Floor ${targetSlot.floorLevel}) allocated to ${reg}`
    };
  },

  getTariffs() {
    this.init();
    const defaults = {
      RATE_FOUR_WHEELER_HOUR: 50,
      RATE_FOUR_WHEELER_DAY: 400,
      RATE_FOUR_WHEELER_MONTH: 3500,
      RATE_FOUR_WHEELER_YEAR: 32000,

      RATE_TWO_WHEELER_HOUR: 20,
      RATE_TWO_WHEELER_DAY: 150,
      RATE_TWO_WHEELER_MONTH: 1200,
      RATE_TWO_WHEELER_YEAR: 10000,

      RATE_EV_HOUR: 60,
      RATE_EV_DAY: 500,
      RATE_EV_MONTH: 4500,
      RATE_EV_YEAR: 40000,

      RATE_HEAVY_VEHICLE_HOUR: 80,
      RATE_HEAVY_VEHICLE_DAY: 700,
      RATE_HEAVY_VEHICLE_MONTH: 6000,
      RATE_HEAVY_VEHICLE_YEAR: 55000,

      RATE_FOUR_WHEELER: 50,
      RATE_TWO_WHEELER: 20,
      RATE_EV: 60,
      RATE_HEAVY_VEHICLE: 80
    };
    try {
      const stored = JSON.parse(localStorage.getItem('SP_TARIFFS_V4') || '{}');
      return { ...defaults, ...stored };
    } catch (e) {
      return defaults;
    }
  },

  calculateExitBill(query, planType = 'hour', planValue = 1, simulatedMinutes = null) {
    this.init();
    const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
    const q = (query || '').trim().toUpperCase();
    const booking = bookings.find(b => (b.bookingCode === q || b.vehicleNumber === q) && b.status === 'ACTIVE');

    if (!booking) {
      throw new Error(`No active parked vehicle found matching: '${query}'`);
    }

    const tariffs = this.getTariffs();
    const vType = booking.vehicleType;

    const hourRate = tariffs[`RATE_${vType}_HOUR`] || booking.hourlyRate || 50;
    const dayRate = tariffs[`RATE_${vType}_DAY`] || 400;
    const monthRate = tariffs[`RATE_${vType}_MONTH`] || 3500;
    const yearRate = tariffs[`RATE_${vType}_YEAR`] || 32000;

    const entry = new Date(booking.entryTime);
    const exit = new Date();
    let minutes = simulatedMinutes || Math.max(1, Math.round((exit - entry) / 60000));
    const elapsedHours = Math.max(1, Math.ceil(minutes / 60));

    let totalAmount = 0;
    let durationFormatted = '';
    let appliedRateLabel = '';

    if (planType === 'day') {
      const days = Math.max(1, planValue || 1);
      totalAmount = days * dayRate;
      durationFormatted = `${days} Day Pass (24h Daily Plan) [Elapsed: ${Math.floor(minutes/60)}h ${minutes%60}m]`;
      appliedRateLabel = `₹${dayRate}.00 / Day`;
    } else if (planType === 'month') {
      const months = Math.max(1, planValue || 1);
      totalAmount = months * monthRate;
      durationFormatted = `${months} Month Pass (30 Days Tier)`;
      appliedRateLabel = `₹${monthRate}.00 / Month`;
    } else if (planType === 'year') {
      const years = Math.max(1, planValue || 1);
      totalAmount = years * yearRate;
      durationFormatted = `${years} Year Annual Pass (365 Days)`;
      appliedRateLabel = `₹${yearRate}.00 / Year`;
    } else {
      // Hourly (1 to 24 hours)
      const hours = Math.max(1, planValue || elapsedHours);
      totalAmount = hours * hourRate;
      const h = Math.floor(minutes / 60);
      const m = minutes % 60;
      durationFormatted = `${hours} Hour${hours > 1 ? 's' : ''} Plan [Parked: ${h}h ${m}m]`;
      appliedRateLabel = `₹${hourRate}.00 / hr`;
    }

    return {
      bookingId: booking.id,
      bookingCode: booking.bookingCode,
      vehicleNumber: booking.vehicleNumber,
      ownerName: booking.ownerName,
      vehicleType: booking.vehicleType,
      slotNumber: booking.slotNumber,
      floorLevel: booking.floorLevel,
      entryTime: booking.entryTime,
      exitTime: exit.toISOString(),
      durationMinutes: minutes,
      durationFormatted,
      hourlyRate: hourRate,
      appliedRateLabel,
      planType,
      planValue,
      totalAmount
    };
  },

  processPayment(req) {
    this.init();
    const bill = this.calculateExitBill(req.bookingCode);
    const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
    const slots = this.getSlots();
    const payments = JSON.parse(localStorage.getItem('SP_PAYMENTS_V4') || '[]');

    const b = bookings.find(x => x.bookingCode === bill.bookingCode);
    if (b) {
      b.status = 'COMPLETED';
      b.exitTime = bill.exitTime;
      b.durationMinutes = bill.durationMinutes;
    }
    localStorage.setItem('SP_BOOKINGS_V4', JSON.stringify(bookings));

    // 🟢 Mark slot AVAILABLE
    const targetSlot = slots.find(s => s.slotNumber === bill.slotNumber);
    if (targetSlot) {
      targetSlot.status = 'AVAILABLE';
      targetSlot.vehicleNumber = null;
      localStorage.setItem('SP_SLOTS_V4', JSON.stringify(slots));
    }

    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const receiptNumber = `REC-${dateStr}-${randSuffix}`;
    const txnId = req.razorpayPaymentId || `TXN-${req.paymentMethod}-${Date.now()}`;

    const newPayment = {
      receiptNumber,
      transactionId: txnId,
      bookingCode: bill.bookingCode,
      vehicleNumber: bill.vehicleNumber,
      ownerName: bill.ownerName,
      slotNumber: bill.slotNumber,
      entryTime: bill.entryTime,
      exitTime: bill.exitTime,
      durationMinutes: bill.durationMinutes,
      durationFormatted: bill.durationFormatted,
      amount: req.amount || bill.totalAmount,
      paymentMethod: req.paymentMethod,
      paymentStatus: 'PAID',
      paymentTime: new Date().toISOString()
    };

    payments.unshift(newPayment);
    localStorage.setItem('SP_PAYMENTS_V4', JSON.stringify(payments));

    return {
      ...newPayment,
      message: `Payment of ₹${newPayment.amount} confirmed. Slot ${bill.slotNumber} is now free!`
    };
  },

  adminLogin(creds) {
    const saved = JSON.parse(localStorage.getItem('SP_ADMIN_CREDS') || 'null') || {
      email: 'admin@smartparking.com',
      password: 'admin123'
    };

    const inputUser = (creds.email || creds.username || '').trim().toLowerCase();
    const inputPass = (creds.password || '').trim();

    const emailMatch = inputUser === saved.email.toLowerCase() || inputUser === 'admin' || inputUser === 'admin@parking.com';
    const passMatch = inputPass === saved.password;

    if (emailMatch && passMatch) {
      return { 
        success: true, 
        message: 'Authentication successful', 
        token: 'demo_token_' + Date.now(),
        adminEmail: saved.email 
      };
    }
    throw new Error('Invalid Admin email or password. Use: admin@smartparking.com / admin123');
  },

  getAdminStats() {
    this.init();
    const slots = this.getSlots();
    const bookings = JSON.parse(localStorage.getItem('SP_BOOKINGS_V4') || '[]');
    const payments = JSON.parse(localStorage.getItem('SP_PAYMENTS_V4') || '[]');
    const tariffs = JSON.parse(localStorage.getItem('SP_TARIFFS_V4') || '{}');

    const totalSlots = slots.length;
    const available = slots.filter(s => s.status === 'AVAILABLE').length;
    const occupied = slots.filter(s => s.status === 'OCCUPIED').length;
    const reserved = slots.filter(s => s.status === 'RESERVED').length;
    const maintenance = slots.filter(s => s.status === 'MAINTENANCE').length;

    const totalRev = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
    const upiRev = payments.filter(p => p.paymentMethod === 'UPI').reduce((acc, p) => acc + (p.amount || 0), 0);
    const cashRev = payments.filter(p => p.paymentMethod === 'CASH').reduce((acc, p) => acc + (p.amount || 0), 0);
    const cardRev = payments.filter(p => p.paymentMethod === 'CARD' || p.paymentMethod === 'RAZORPAY').reduce((acc, p) => acc + (p.amount || 0), 0);
    const completedCount = bookings.filter(b => b.status === 'COMPLETED').length;
    const activeCount = bookings.filter(b => b.status === 'ACTIVE').length;

    return {
      totalSlots,
      availableSlots: available,
      occupiedSlots: occupied,
      reservedSlots: reserved,
      maintenanceSlots: maintenance,
      occupancyRatePercentage: totalSlots > 0 ? ((occupied / totalSlots) * 100).toFixed(1) : 0,
      incomingVehiclesTotal: bookings.length,
      outgoingVehiclesTotal: completedCount,
      currentlyParkedVehicles: activeCount,
      todayRevenue: totalRev,
      totalRevenue: totalRev,
      upiRevenue: upiRev,
      cashRevenue: cashRev,
      cardRevenue: cardRev,
      currentTariffs: tariffs
    };
  },

  toggleSlotMaintenance(slotNumber) {
    this.init();
    const slots = this.getSlots();
    const s = slots.find(x => x.slotNumber === slotNumber);
    if (!s) throw new Error('Slot not found');
    s.status = (s.status === 'MAINTENANCE') ? 'AVAILABLE' : 'MAINTENANCE';
    if (s.status === 'MAINTENANCE') s.vehicleNumber = null;
    localStorage.setItem('SP_SLOTS_V4', JSON.stringify(slots));
    return s;
  },

  toggleSlotEv(slotNumber) {
    this.init();
    const slots = this.getSlots();
    const s = slots.find(x => x.slotNumber === slotNumber);
    if (!s) throw new Error('Slot not found');
    s.hasEvCharger = !s.hasEvCharger;
    localStorage.setItem('SP_SLOTS_V4', JSON.stringify(slots));
    return s;
  },

  updateAdminPassword(newPassword) {
    const creds = JSON.parse(localStorage.getItem('SP_ADMIN_CREDS') || 'null') || {
      email: 'admin@smartparking.com',
      password: 'admin123'
    };
    creds.password = newPassword;
    localStorage.setItem('SP_ADMIN_CREDS', JSON.stringify(creds));
    return { success: true, message: 'Admin password updated successfully' };
  },

  updateTariffs(rates) {
    this.init();
    const cur = this.getTariffs();
    const tariffs = {
      RATE_FOUR_WHEELER_HOUR: Number(rates.fourWheelerHour || rates.fourWheelerRate || cur.RATE_FOUR_WHEELER_HOUR),
      RATE_FOUR_WHEELER_DAY: Number(rates.fourWheelerDay || cur.RATE_FOUR_WHEELER_DAY),
      RATE_FOUR_WHEELER_MONTH: Number(rates.fourWheelerMonth || cur.RATE_FOUR_WHEELER_MONTH),
      RATE_FOUR_WHEELER_YEAR: Number(rates.fourWheelerYear || cur.RATE_FOUR_WHEELER_YEAR),

      RATE_TWO_WHEELER_HOUR: Number(rates.twoWheelerHour || rates.twoWheelerRate || cur.RATE_TWO_WHEELER_HOUR),
      RATE_TWO_WHEELER_DAY: Number(rates.twoWheelerDay || cur.RATE_TWO_WHEELER_DAY),
      RATE_TWO_WHEELER_MONTH: Number(rates.twoWheelerMonth || cur.RATE_TWO_WHEELER_MONTH),
      RATE_TWO_WHEELER_YEAR: Number(rates.twoWheelerYear || cur.RATE_TWO_WHEELER_YEAR),

      RATE_EV_HOUR: Number(rates.evHour || rates.evRate || cur.RATE_EV_HOUR),
      RATE_EV_DAY: Number(rates.evDay || cur.RATE_EV_DAY),
      RATE_EV_MONTH: Number(rates.evMonth || cur.RATE_EV_MONTH),
      RATE_EV_YEAR: Number(rates.evYear || cur.RATE_EV_YEAR),

      RATE_HEAVY_VEHICLE_HOUR: Number(rates.heavyVehicleHour || rates.heavyVehicleRate || cur.RATE_HEAVY_VEHICLE_HOUR),
      RATE_HEAVY_VEHICLE_DAY: Number(rates.heavyVehicleDay || cur.RATE_HEAVY_VEHICLE_DAY),
      RATE_HEAVY_VEHICLE_MONTH: Number(rates.heavyVehicleMonth || cur.RATE_HEAVY_VEHICLE_MONTH),
      RATE_HEAVY_VEHICLE_YEAR: Number(rates.heavyVehicleYear || cur.RATE_HEAVY_VEHICLE_YEAR),

      RATE_FOUR_WHEELER: Number(rates.fourWheelerHour || rates.fourWheelerRate || cur.RATE_FOUR_WHEELER_HOUR),
      RATE_TWO_WHEELER: Number(rates.twoWheelerHour || rates.twoWheelerRate || cur.RATE_TWO_WHEELER_HOUR),
      RATE_EV: Number(rates.evHour || rates.evRate || cur.RATE_EV_HOUR),
      RATE_HEAVY_VEHICLE: Number(rates.heavyVehicleHour || rates.heavyVehicleRate || cur.RATE_HEAVY_VEHICLE_HOUR)
    };
    localStorage.setItem('SP_TARIFFS_V4', JSON.stringify(tariffs));

    // Instantly update slot base rates across all 4 floors so grid reflects change!
    const slots = this.getSlots();
    slots.forEach(slot => {
      if (slot.slotType === 'FOUR_WHEELER') slot.baseHourlyRate = tariffs.RATE_FOUR_WHEELER_HOUR;
      else if (slot.slotType === 'TWO_WHEELER') slot.baseHourlyRate = tariffs.RATE_TWO_WHEELER_HOUR;
      else if (slot.slotType === 'EV') slot.baseHourlyRate = tariffs.RATE_EV_HOUR;
      else if (slot.slotType === 'HEAVY_VEHICLE') slot.baseHourlyRate = tariffs.RATE_HEAVY_VEHICLE_HOUR;
    });
    localStorage.setItem('SP_SLOTS_V4', JSON.stringify(slots));

    return { message: 'Tariffs updated successfully and applied to all 40 bays!', tariffs };
  }
};
