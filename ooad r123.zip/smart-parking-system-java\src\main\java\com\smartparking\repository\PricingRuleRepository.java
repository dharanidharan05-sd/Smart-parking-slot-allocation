package com.smartparking.repository;

import com.smartparking.entity.PricingRule;
import com.smartparking.enums.VehicleCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PricingRuleRepository extends JpaRepository<PricingRule, Long> {
    Optional<PricingRule> findByCategory(VehicleCategory category);
}
