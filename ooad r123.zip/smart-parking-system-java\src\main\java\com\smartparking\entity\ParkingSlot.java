package com.smartparking.entity;

import com.smartparking.enums.SlotStatus;
import com.smartparking.enums.VehicleCategory;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "parking_slots", indexes = {
    @Index(name = "idx_slot_status_cat", columnList = "category, status, walk_distance_units")
})
public class ParkingSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "slot_number", nullable = false, unique = true, length = 20)
    private String slotNumber; // B01, C01, CM01, HV01

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "zone_id", nullable = false)
    private ParkingZone zone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private VehicleCategory category = VehicleCategory.FOUR_WHEELER;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private SlotStatus status = SlotStatus.AVAILABLE;

    @Column(name = "length_meters")
    private Double lengthMeters = 5.0;

    @Column(name = "width_meters")
    private Double widthMeters = 2.4;

    @Column(name = "assigned_vehicle_plate", length = 30)
    private String assignedVehiclePlate;

    @Column(name = "has_ev_charger")
    private Boolean hasEvCharger = false;

    @Column(name = "walk_distance_units")
    private Integer walkDistanceUnits = 10; // lower score = closer to gate

    @Column(name = "current_session_id")
    private Long currentSessionId;

    @Version
    @Column(nullable = false)
    private Long version = 0L; // Concurrency protection against simultaneous double booking!

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    public ParkingSlot() {}

    public ParkingSlot(String slotNumber, ParkingZone zone, VehicleCategory category, 
                       SlotStatus status, Double lengthMeters, Double widthMeters, 
                       Boolean hasEvCharger, Integer walkDistanceUnits) {
        this.slotNumber = slotNumber;
        this.zone = zone;
        this.category = category;
        this.status = status;
        this.lengthMeters = lengthMeters;
        this.widthMeters = widthMeters;
        this.hasEvCharger = hasEvCharger;
        this.walkDistanceUnits = walkDistanceUnits;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSlotNumber() { return slotNumber; }
    public void setSlotNumber(String slotNumber) { this.slotNumber = slotNumber; }

    public ParkingZone getZone() { return zone; }
    public void setZone(ParkingZone zone) { this.zone = zone; }

    public VehicleCategory getCategory() { return category; }
    public void setCategory(VehicleCategory category) { this.category = category; }

    public SlotStatus getStatus() { return status; }
    public void setStatus(SlotStatus status) { this.status = status; }

    public Double getLengthMeters() { return lengthMeters; }
    public void setLengthMeters(Double lengthMeters) { this.lengthMeters = lengthMeters; }

    public Double getWidthMeters() { return widthMeters; }
    public void setWidthMeters(Double widthMeters) { this.widthMeters = widthMeters; }

    public String getAssignedVehiclePlate() { return assignedVehiclePlate; }
    public void setAssignedVehiclePlate(String assignedVehiclePlate) { this.assignedVehiclePlate = assignedVehiclePlate; }

    public Boolean getHasEvCharger() { return hasEvCharger; }
    public void setHasEvCharger(Boolean hasEvCharger) { this.hasEvCharger = hasEvCharger; }

    public Integer getWalkDistanceUnits() { return walkDistanceUnits; }
    public void setWalkDistanceUnits(Integer walkDistanceUnits) { this.walkDistanceUnits = walkDistanceUnits; }

    public Long getCurrentSessionId() { return currentSessionId; }
    public void setCurrentSessionId(Long currentSessionId) { this.currentSessionId = currentSessionId; }

    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
