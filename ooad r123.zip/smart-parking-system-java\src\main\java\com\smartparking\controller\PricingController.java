package com.smartparking.controller;

import com.smartparking.dto.ApiResponse;
import com.smartparking.dto.PricingUpdateRequest;
import com.smartparking.entity.AuditLog;
import com.smartparking.entity.PricingRule;
import com.smartparking.enums.VehicleCategory;
import com.smartparking.repository.AuditLogRepository;
import com.smartparking.repository.PricingRuleRepository;
import com.smartparking.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/pricing")
@CrossOrigin(origins = "*")
public class PricingController {

    @Autowired
    private PricingRuleRepository pricingRuleRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Autowired
    private AuditService auditService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<PricingRule>>> getAllPricingRules() {
        return ResponseEntity.ok(ApiResponse.success(pricingRuleRepository.findAll()));
    }

    @PutMapping("/{category}")
    public ResponseEntity<ApiResponse<PricingRule>> updatePricingRule(
            @PathVariable VehicleCategory category,
            @Valid @RequestBody PricingUpdateRequest request) {

        PricingRule rule = pricingRuleRepository.findByCategory(category)
                .orElseThrow(() -> new IllegalArgumentException("Tariff rule not found for: " + category));

        String oldHourly = rule.getHourlyRate().toString();

        rule.setHourlyRate(request.getHourlyRate());
        rule.setDailyRate(request.getDailyRate());
        rule.setMonthlyRate(request.getMonthlyRate());
        rule.setYearlyRate(request.getYearlyRate());
        if (request.getGracePeriodMinutes() != null) rule.setGracePeriodMinutes(request.getGracePeriodMinutes());
        rule.setOvertimeRatePerHour(request.getOvertimeRatePerHour());
        if (request.getTaxPercent() != null) rule.setTaxPercent(request.getTaxPercent());
        rule.setEffectiveDate(LocalDateTime.now());
        rule.setLastUpdateReason(request.getReason());
        rule.setUpdatedBy(request.getUpdatedBy() != null ? request.getUpdatedBy() : "Admin");

        PricingRule updated = pricingRuleRepository.save(rule);

        auditService.logEvent("PRICING_UPDATED", "PRICING_RULE", category.name(), 
                "₹" + oldHourly + "/hr", "₹" + request.getHourlyRate() + "/hr", request.getReason());

        return ResponseEntity.ok(ApiResponse.success("Tariff for " + category + " updated successfully", updated));
    }

    @GetMapping("/audit")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getPricingAuditHistory() {
        return ResponseEntity.ok(ApiResponse.success(auditLogRepository.findByResourceTypeOrderByCreatedAtDesc("PRICING_RULE")));
    }
}
