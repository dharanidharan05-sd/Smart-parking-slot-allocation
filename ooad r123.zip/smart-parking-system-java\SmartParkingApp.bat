@echo off
title Launching Smart Parking System App
color 0a
echo ===============================================================================
echo                LAUNCHING SMART PARKING APPLICATION (APP MODE)
echo ===============================================================================
echo.
echo 1. Starting Spring Boot Backend Services...

REM Check if backend is already running
curl -s -I http://localhost:8080 >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    start "Smart Parking Backend" /min cmd /c "run-backend.bat"
    echo 2. Initializing 40 bays across 4 floors...
    timeout /t 6 /nobreak >nul
)

echo 3. Opening Dedicated Standalone Application Window...

REM Launch in App Window Mode (No browser tabs or address bar!)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:8080 --window-size=1300,850
    goto RUNNING
)

if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:8080 --window-size=1300,850
    goto RUNNING
)

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:8080 --window-size=1300,850
    goto RUNNING
)

if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:8080 --window-size=1300,850
    goto RUNNING
)

REM Fallback to default browser
start http://localhost:8080

:RUNNING
echo.
echo ===============================================================================
echo  Smart Parking App is running!
echo  URL:                     http://localhost:8080
echo  Connect from any Wi-Fi:  Run connect-from-any-wifi.bat
echo ===============================================================================
exit
